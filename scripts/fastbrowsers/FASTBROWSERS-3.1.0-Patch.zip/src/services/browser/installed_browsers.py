"""Host browser adapters. Nothing is redistributed; we locate legal local installs.

Edge uses the Microsoft-supported Chromium Playwright interface. Cốc Cốc and
Brave use best-effort executable_path and may differ in Playwright support.
"""
from __future__ import annotations
import os
from pathlib import Path

BRANDED = {"edge":"Microsoft Edge", "coccoc":"Cốc Cốc", "brave":"Brave"}

def candidates(engine: str) -> list[Path]:
    if engine not in BRANDED:
        return []
    local = Path(os.getenv("LOCALAPPDATA") or "")
    program = Path(os.getenv("PROGRAMFILES") or "C:/Program Files")
    program86 = Path(os.getenv("PROGRAMFILES(X86)") or "C:/Program Files (x86)")
    locations = {
        "edge":[program86/"Microsoft/Edge/Application/msedge.exe", program/"Microsoft/Edge/Application/msedge.exe", local/"Microsoft/Edge/Application/msedge.exe"],
        "coccoc":[local/"CocCoc/Browser/Application/browser.exe",program/"CocCoc/Browser/Application/browser.exe",program86/"CocCoc/Browser/Application/browser.exe"],
        "brave":[program/"BraveSoftware/Brave-Browser/Application/brave.exe",program86/"BraveSoftware/Brave-Browser/Application/brave.exe",local/"BraveSoftware/Brave-Browser/Application/brave.exe"],
    }
    return locations[engine]

def executable(engine: str) -> Path | None:
    for path in candidates(engine):
        if path.is_file():
            return path
    return None

def available(engine: str) -> bool:
    return executable(engine) is not None

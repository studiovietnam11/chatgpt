"""One-click creation and independent re-rolls for profile settings.

Numbers in metadata do not pretend to modify system hardware.
"""
from __future__ import annotations
import secrets
import sys
from ...models.device_settings import validate_settings

SCREENS = ("1366x768", "1440x900", "1600x900", "1920x1080", "2560x1440")
DEVICES = ("desktop", "laptop", "workstation")
CORES = (2, 4, 6, 8, 12, 16)
RANDOM_RAM = (4, 8, 16, 32)


def random_settings(os_type: str = "windows") -> dict:
    """New independent settings each invocation; OS version remains compatible."""
    versions = {"windows":("windows10","windows11"),
                "macos":("macos14","macos15","macos26"),
                "linux":("linux6",)}
    raw = {
        "device_class": secrets.choice(DEVICES),
        "os_version": secrets.choice(versions.get(os_type, ("auto",))),
        "screen": secrets.choice(SCREENS),
        "cpu_cores": secrets.choice(CORES),
        "ram_gb": secrets.choice(RANDOM_RAM),
    }
    return validate_settings(raw, os_type)


def new_name(existing_names=()) -> str:
    names={n.casefold() for n in existing_names}
    for _ in range(100):
        name = "FB-" + secrets.token_hex(4).upper()
        if name.casefold() not in names:
            return name
    raise RuntimeError("Could not allocate unique profile name")


def create_random_profile(pm, engine: str = "camoufox", os_type: str | None = None):
    """Atomically add a newly randomized, distinct local profile."""
    if os_type is None:
        os_type={"win32":"windows", "darwin":"macos"}.get(sys.platform,"linux")
    for _ in range(15):
        name = new_name(pm.profiles.keys())
        settings = random_settings(os_type)
        if pm.add_profile(name, "", os_type, engine=engine, settings=settings):
            return pm.profiles[name]
    raise RuntimeError("Could not save a unique profile")

"""FASTBROWSERS 3.1 professional workspace, native Flet controls.

Strong layout hierarchy, consistent spacing, live numbers, no static fake KPIs.
"""
from __future__ import annotations
import flet as ft
from ..theme.colors import COLORS, FONT_BOLD, FONT_SEMIBOLD


def title(text, size=14, color=None):
    return ft.Text(text, size=size, font_family=FONT_SEMIBOLD,
                   color=color or COLORS["text_main"], weight=ft.FontWeight.W_600)


def stat(label, value, symbol, featured=False):
    value.size=30 if featured else 25
    value.font_family=FONT_BOLD
    value.weight=ft.FontWeight.W_700
    value.color=COLORS["text_main"]
    value.no_wrap=True
    color = COLORS["accent"] if featured else COLORS["text_sub"]
    return ft.Container(
        expand=True, height=126 if featured else 116, bgcolor=COLORS["card_bg"],
        border=ft.Border.all(1,COLORS["card_border"]), border_radius=14,
        padding=ft.Padding.symmetric(horizontal=19,vertical=17),
        content=ft.Column(spacing=8,controls=[
            ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[
                ft.Text(label,size=12.5,color=COLORS["text_sub"],weight=ft.FontWeight.W_500),
                ft.Container(width=32,height=32,bgcolor=COLORS["accent_soft"] if featured else COLORS["paper_sunk"],
                    border_radius=9,alignment=ft.Alignment(0,0),
                    content=ft.Icon(symbol,color=color,size=17))]),
            value,
        ]),
    )


def summary_panel(name, intro, text_control, symbol, status=None):
    text_control.size=12.5
    text_control.color=COLORS["text_sub"]
    text_control.max_lines=6
    return ft.Container(
        expand=True,height=205,bgcolor=COLORS["card_bg"],
        border=ft.Border.all(1,COLORS["card_border"]),border_radius=14,
        padding=ft.Padding.symmetric(horizontal=18,vertical=16),
        content=ft.Column(spacing=10,controls=[
            ft.Row(spacing=9,controls=[
                ft.Container(width=34,height=34,bgcolor=COLORS["accent_soft"],
                    border_radius=10,alignment=ft.Alignment(0,0),
                    content=ft.Icon(symbol,size=18,color=COLORS["accent"])),
                ft.Column(spacing=2,controls=[
                    title(name,13.5),
                    ft.Text(intro,size=10.5,color=COLORS["text_dim"]),
                ])
            ]),
            ft.Divider(height=1,color=COLORS["card_border"]),
            text_control,
        ]),
    )


def section_heading(name,detail):
    return ft.Row(spacing=9,controls=[
        ft.Container(width=4,height=18,border_radius=4,bgcolor=COLORS["accent"]),
        title(name,15),
        ft.Text(detail,size=12,color=COLORS["text_dim"]),
    ])


def build_content_area(
    subtitle: ft.Text, profile_list: ft.Column, prev_btn: ft.IconButton,
    next_btn: ft.IconButton, page_label: ft.Text,
    bulk_bar: ft.Control | None = None, search_field: ft.Control | None = None,
    header_slot: ft.Container | None = None,
    metrics: tuple[ft.Text, ...] | None = None,
    engine_inventory: ft.Text | None = None,
    environment_text: ft.Text | None = None,
    proxy_text: ft.Text | None = None,
    on_random_profile=None,
    on_new_profile=None,
) -> ft.Container:
    # This is always the live profile table, not a second fake list.
    sheet=ft.Container(
        height=385, bgcolor=COLORS["card_bg"], border_radius=14,
        border=ft.Border.all(1,COLORS["card_border"]),
        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        content=ft.Column(spacing=0,expand=True,controls=[
            *([bulk_bar] if bulk_bar is not None else []),
            *([header_slot] if header_slot is not None else []),
            profile_list,
        ]),
    )
    hero=ft.Container(
        padding=ft.Padding.symmetric(vertical=18,horizontal=22),
        bgcolor=COLORS["card_bg"],border_radius=16,
        border=ft.Border.all(1,COLORS["card_border"]),
        content=ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER,controls=[
            ft.Container(width=50,height=50,border_radius=14,
                bgcolor=COLORS["accent_soft"],alignment=ft.Alignment(0,0),
                content=ft.Icon(ft.Icons.SPACE_DASHBOARD_OUTLINED,size=25,color=COLORS["accent"])),
            ft.Column(spacing=4,expand=True,controls=[
                ft.Text("TỔNG QUAN / OVERVIEW",size=10.5,
                    color=COLORS["accent"],weight=ft.FontWeight.W_700),
                ft.Text("Browser Workspace",size=25,font_family=FONT_BOLD,
                    weight=ft.FontWeight.W_700,color=COLORS["text_main"]),
                subtitle,
            ]),
            ft.Container(padding=ft.Padding.symmetric(horizontal=12,vertical=7),
                bgcolor="#EAF8F0",border_radius=8,
                content=ft.Row(spacing=6,controls=[
                    ft.Icon(ft.Icons.CIRCLE,size=8,color="#17814B"),
                    ft.Text("LOCAL WORKSPACE",size=11,color="#17653F",weight=ft.FontWeight.W_600)
                ])),
        ]),
    )
    controls=[hero,ft.Container(height=18)]
    if metrics and len(metrics)>=8:
        controls += [section_heading("Thống kê hoạt động","Dữ liệu cập nhật theo profile hiện có"),
                     ft.Container(height=12),
                     ft.Row(spacing=12,controls=[
                         stat("Tổng profile",metrics[0],ft.Icons.LAYERS_OUTLINED,True),
                         stat("Đang hoạt động",metrics[1],ft.Icons.PLAY_CIRCLE_OUTLINE),
                         stat("Đã dừng",metrics[2],ft.Icons.PAUSE_CIRCLE_OUTLINE),
                         stat("Sử dụng proxy",metrics[3],ft.Icons.SHIELD_OUTLINED),
                     ]),ft.Container(height=12),
                     ft.Row(spacing=12,controls=[
                         stat("Camoufox",metrics[4],ft.Icons.PUBLIC),
                         stat("Chromium / Edge / Cốc Cốc",metrics[5],ft.Icons.WEB_OUTLINED),
                         stat("Tổ hợp OS",metrics[6],ft.Icons.DESKTOP_WINDOWS_OUTLINED),
                         stat("Loại thiết bị",metrics[7],ft.Icons.DEVICES_OUTLINED),
                     ]),ft.Container(height=22)]
    if all(x is not None for x in (engine_inventory,environment_text,proxy_text)):
        controls += [section_heading("Sức khỏe môi trường","Engine thật, thiết bị, kết nối"),
                     ft.Container(height=12),
                     ft.Row(spacing=12,controls=[
                         summary_panel("Browser engines","Installed / configured",engine_inventory,ft.Icons.MEMORY),
                         summary_panel("Thiết bị & OS","OS version / device type",environment_text,ft.Icons.MONITOR),
                         summary_panel("Tình trạng kết nối","Proxy / direct / stopped",proxy_text,ft.Icons.LAN),
                     ]),ft.Container(height=24)]
    toolbar=ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER,spacing=9,controls=[
        ft.Column(spacing=2,expand=True,controls=[
            title("Danh sách môi trường",16),
            ft.Text("Tạo, chạy, dừng và quản lý từng phiên trình duyệt",size=12,color=COLORS["text_dim"]),
        ]),
        *([search_field] if search_field is not None else []),
        ft.OutlinedButton("Ngẫu nhiên",icon=ft.Icons.CASINO_OUTLINED,
            on_click=on_random_profile,
            tooltip="Tạo ngay profile mới với tên và cấu hình ngẫu nhiên"),
        ft.Button("Tạo profile",icon=ft.Icons.ADD,
            on_click=on_new_profile,
            style=ft.ButtonStyle(bgcolor=COLORS["accent"],color="#FFFFFF")),
    ])
    controls += [toolbar,ft.Container(height=12),sheet,
                 ft.Container(height=8),
                 ft.Row(alignment=ft.MainAxisAlignment.END,
                        controls=[prev_btn,page_label,next_btn]),ft.Container(height=16)]
    return ft.Container(expand=True,bgcolor=COLORS["bg"],
        padding=ft.Padding.only(left=28,right=28,top=24,bottom=12),
        content=ft.Column(expand=True,scroll=ft.ScrollMode.AUTO,
                          spacing=0,controls=controls))

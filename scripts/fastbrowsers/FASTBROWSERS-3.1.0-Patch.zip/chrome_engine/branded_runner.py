"""Installed branded Chromium adapters: Edge stable; Cốc Cốc and Brave beta.

Important: these are standard browser instances, NOT fingerprint-chromium and
NOT equivalent to native anti-detect browsers. No proprietary binaries bundled.
"""
from __future__ import annotations
import asyncio
import contextlib
import json
import os
import sys
from pathlib import Path
from playwright.async_api import async_playwright
from src.core.config import DATA_DIR, PROFILES_FILE, RESTORE_TABS, HEADLESS
from src.services.browser.installed_browsers import BRANDED, executable
from src.services.browser import control, session
from src.services.browser.runner import restore_tabs, snapshot_tabs
from src.utils.proxy_parser import parse_proxy


def profile_engine(name: str) -> str:
    with Path(PROFILES_FILE).open(encoding="utf-8") as handle:
        return json.load(handle)[name]["engine"]

async def run_browser(name: str, proxy_string: str, os_type: str,
                      timezone: str = "", locale: str = "") -> int:
    engine = profile_engine(name)
    if engine not in BRANDED:
        print("LAUNCH_FAILED: Unexpected local browser engine", flush=True)
        return 2
    path=executable(engine)
    if path is None:
        print("LAUNCH_FAILED: "+BRANDED[engine]+" is not installed on this Windows PC",flush=True)
        return 2
    data_dir=Path(DATA_DIR)/name
    data_dir.mkdir(parents=True,exist_ok=True)
    proxy=parse_proxy(proxy_string)
    context=None
    try:
        async with async_playwright() as pw:
            kwargs={"headless":HEADLESS is True,
                    "accept_downloads":True, "no_viewport":True,
                    "args":["--no-first-run", "--no-default-browser-check"]}
            if engine == "edge":
                kwargs["channel"] = "msedge"  # official Playwright-supported Edge channel
            else:
                kwargs["executable_path"] = str(path)  # experimental third-party Chromium
            if proxy:
                kwargs["proxy"]=proxy
            if timezone: kwargs["timezone_id"]=timezone
            if locale: kwargs["locale"]=locale
            context=await pw.chromium.launch_persistent_context(str(data_dir),**kwargs)
            if not context.pages: await context.new_page()
            if RESTORE_TABS:
                await restore_tabs(context, session.load(str(data_dir)))
            close=asyncio.Event()
            def on_page_close(_):
                if not any(not page.is_closed() for page in context.pages):
                    close.set()
            for page in context.pages: page.on("close",on_page_close)
            context.on("page",lambda p:p.on("close",on_page_close))
            context.on("close", lambda _:close.set())
            server,port,token=await control.serve(context)
            print(f"CONTROL:{port}:{token}",flush=True)
            print("BROWSER_STARTED",flush=True)
            snapshot=(asyncio.create_task(snapshot_tabs(context,str(data_dir),close)) if RESTORE_TABS else None)
            try:
                await close.wait()
            finally:
                if snapshot: snapshot.cancel()
                with contextlib.suppress(Exception): await server.cleanup()
                with contextlib.suppress(Exception):await context.close()
            print("BROWSER_CLOSED",flush=True)
            return 0
    except Exception as e:
        print(f"LAUNCH_FAILED: {type(e).__name__}: {str(e)[:350]}",flush=True)
        return 1

def main() -> int:
    if len(sys.argv)<4: return 2
    argv=sys.argv[1:6]
    try: return asyncio.run(run_browser(*argv))
    except KeyboardInterrupt: return 130

if __name__=="__main__":
    raise SystemExit(main())

"""Regression coverage for new browser engines and one-click random profiles."""
from pathlib import Path
from src.models.profile import ENGINES, Profile
from src.models.device_settings import validate_settings
from src.services.profile.random_profile import random_settings, new_name, create_random_profile
from src.services.browser.installed_browsers import BRANDED, candidates, available
from src.services.browser.process import runner_command


def test_new_browser_labels_and_paths():
    assert {"camoufox","chrome","edge","coccoc","brave"} <= set(ENGINES)
    assert BRANDED["edge"] == "Microsoft Edge"
    assert BRANDED["coccoc"] == "Cốc Cốc"
    assert any(str(p).lower().endswith("msedge.exe") for p in candidates("edge"))
    assert any(str(p).lower().endswith("browser.exe") for p in candidates("coccoc"))


def test_random_settings_are_valid_for_each_os():
    for system in ("windows", "macos", "linux"):
        for _ in range(30):
            settings = random_settings(system)
            assert settings == validate_settings(settings,system)
            assert settings["cpu_cores"] in (2,4,6,8,12,16)
            assert settings["screen"] != "auto"
            assert settings["web_rtc"] == "engine"
            assert settings["canvas"] == "engine"


def test_random_names_unique_and_safe():
    names = [new_name() for _ in range(250)]
    assert len(names) == len(set(names))
    assert all(name.startswith("FB-") and len(name)==11 for name in names)
    assert new_name(names) not in names


def test_random_creation_never_overwrites_existing():
    class FakeManager:
        def __init__(self):self.profiles = {}
        def add_profile(self,name,proxy,os_type,**kwargs):
            if name in self.profiles:return False
            self.profiles[name]=Profile(name,proxy,os_type,engine=kwargs["engine"],settings=kwargs["settings"])
            return True
    pm=FakeManager()
    first=create_random_profile(pm,os_type="windows")
    second=create_random_profile(pm,os_type="windows")
    assert first.name!=second.name
    assert len(pm.profiles)==2
    assert first.engine==second.engine=="camoufox"


def test_runner_routes_branded_engine_as_independent_python_worker():
    for engine in ("edge","coccoc","brave"):
        command=runner_command(Profile(name="FAKE",engine=engine))
        assert command[1:3]==["-m","chrome_engine.branded_runner"]
        assert command[3]=="FAKE"
    chrome=runner_command(Profile(name="FAKE",engine="chrome"))
    assert chrome[1:3]==["-m","chrome_engine.runner"]

# FASTBROWSERS 3.1.0 — Browser Workspace

## Thiết kế
- UI desktop sáng cam–trắng, Inter; hierarchy rõ với thanh header và dashboard phân nhóm.
- Profile table là dữ liệu thật, hỗ trợ tìm kiếm, bộ lọc, trạng thái, khởi chạy/dừng.
- Nút **Tạo nhanh ngẫu nhiên** trên sidebar và thanh bảng tạo và LƯU profile mới ngay.
- Nút **Ngẫu nhiên lại cấu hình** trong popup đổi tên/cpu/ram/độ phân giải/thiết bị; chưa lưu cho đến khi bấm Tạo profile.

## Engine
- Camoufox (tích hợp) và Chromium patched (nguồn gốc) vẫn như trước.
- Microsoft Edge (đã cài trên Windows; Playwright Chromium), Cốc Cốc beta (đã cài), Brave beta (đã cài).
- Các browser branded dùng executable của hệ thống, **không đóng gói lại**; hỗ trợ automation khác nhau theo phiên bản.
- Chrome patched fingerprint là engine riêng; profile của các engine khác nhau KHÔNG dùng chung thư mục dữ liệu.
- Cốc Cốc/Brave là lựa chọn experimental; không hứa fingerprint spoofing hoặc luôn tương thích.
- Tạo profile với engine chưa cài sẽ có cảnh báo cụ thể. 

## Ngẫu nhiên
- Tên FB-XXXXXXXX riêng, giá trị thiết bị/cpu/ram/screen/OS mới.
- Cấu hình ngẫu nhiên không có proxy tự phát hoặc timezone/locale mâu thuẫn: hai trường đó theo auto/IP.
- Một số field chỉ là metadata, không ngụ ý giả lập phần cứng.

## Cài đặt
- Windows x64: chỉ dùng file FASTBROWSERS-Setup-3.1.0-Win64.exe sau khi build và kiểm tra.
- Không yêu cầu người sử dụng cài Python. Bảo toàn dữ liệu profile cũ (dữ liệu dưới LOCALAPPDATA).

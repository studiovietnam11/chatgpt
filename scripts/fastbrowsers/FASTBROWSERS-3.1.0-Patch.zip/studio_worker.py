"""Console-subsystem worker for browser profiles in frozen Windows builds.

A Flet GUI executable is windowed and cannot safely be re-launched as a Python
interpreter (nor does it reliably expose stdout). This helper is packaged as
an independent console executable, launched by the GUI with pipes for the
existing CONTROL/BROWSER_STARTED protocol.
"""
from __future__ import annotations

import asyncio
import os
import sys
import traceback
from pathlib import Path


def browser_runtime() -> Path:
    configured = os.getenv("FOXPROFILE_BROWSER_RUNTIME", "")
    if configured:
        return Path(configured).resolve()
    root = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    if root.name.lower() == "worker":
        root = root.parent
    return root / "browser-runtime"


def configure_browser() -> None:
    if not getattr(sys, "frozen", False):
        return
    cache = browser_runtime()
    if not cache.is_dir():
        raise FileNotFoundError(f"Bundled Camoufox runtime not found: {cache}")
    import camoufox.pkgman as pkgman
    pkgman.INSTALL_DIR = cache


def main() -> int:
    argv = sys.argv[1:]
    if argv and argv[0] == "--self-test":
        configure_browser()
        from src.services.browser import runner  # noqa: F401
        from chrome_engine import runner as chrome_runner  # noqa: F401
        from chrome_engine import branded_runner  # noqa: F401
        if getattr(sys, "frozen", False):
            from camoufox.pkgman import launch_path
            if not Path(launch_path()).is_file():
                raise FileNotFoundError("Bundled Camoufox executable missing")
        print("FASTBROWSERS browser worker self-test OK", flush=True)
        return 0
    if len(argv) < 4 or argv[0] not in ("--camoufox", "--chrome", "--branded"):
        print("Usage: FoxProfileWorker.exe --camoufox|--chrome <name> <proxy> <os> [timezone] [locale]",flush=True)
        return 2
    configure_browser()
    engine = argv[0]
    sys.argv = [sys.argv[0], *argv[1:]]
    if engine == "--chrome":
        from chrome_engine.runner import main as run_chrome
        return run_chrome()
    if engine == "--branded":
        from chrome_engine.branded_runner import main as run_branded
        return run_branded()
    from src.services.browser.runner import _async_main, _configure_stdio
    _configure_stdio()
    return asyncio.run(_async_main())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)

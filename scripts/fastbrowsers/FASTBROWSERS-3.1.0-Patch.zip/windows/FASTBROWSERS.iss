#define MyAppName "FASTBROWSERS"
#define MyAppVersion "3.1.0"
[Setup]
AppId={{A26A181C-4F1B-4F16-8583-B48420CB3B00}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=FASTBROWSERS
DefaultDirName={localappdata}\Programs\FASTBROWSERS
DefaultGroupName=FASTBROWSERS
DisableProgramGroupPage=yes
OutputDir=..\release
OutputBaseFilename=FASTBROWSERS-Setup-3.1.0-Win64
Compression=zip
SolidCompression=no
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
CloseApplications=yes
SetupIconFile=..\src\assets\icon.ico
UninstallDisplayIcon={app}\FASTBROWSERS.exe
[Files]
Source: "..\dist\FASTBROWSERS\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{autoprograms}\FASTBROWSERS"; Filename: "{app}\FASTBROWSERS.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\FASTBROWSERS"; Filename: "{app}\FASTBROWSERS.exe"; WorkingDir: "{app}"
Name: "{autoprograms}\Uninstall FASTBROWSERS"; Filename: "{uninstallexe}"
[Run]
Filename: "{app}\FASTBROWSERS.exe"; Description: "Mở FASTBROWSERS"; Flags: nowait postinstall skipifsilent

param()
$ErrorActionPreference = "Stop"
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
python -m pip install -U pip
python -m pip install -r requirements.txt
python -m pip install "flet==0.80.5" "flet-desktop==0.80.5" "pyinstaller>=6.10,<7" "typer"
python -m pip install pytest
python -m pytest -q tests/test_fastbrowsers_31.py tests/test_dockerprofile_device.py tests/test_strings.py tests/test_validation.py tests/test_state.py
if ($LASTEXITCODE -ne 0) { throw 'FASTBROWSERS regression tests failed' }
python -m compileall -q src chrome_engine studio_launcher.py studio_worker.py
if ($LASTEXITCODE -ne 0) { throw 'Source compilation failed' }
python -m camoufox fetch
if ($LASTEXITCODE -ne 0) { throw 'Camoufox fetch failed' }
# Inter: fetched by BUILD worker from the Google Fonts repository (OFL).
New-Item -ItemType Directory -Force -Path 'src/assets/fonts' | Out-Null
$inter='https://raw.githubusercontent.com/google/fonts/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf'
Invoke-WebRequest -Uri $inter -OutFile 'src/assets/fonts/Inter-Regular.ttf'
foreach ($w in @('Medium','SemiBold','Bold')) { Copy-Item 'src/assets/fonts/Inter-Regular.ttf' "src/assets/fonts/Inter-$w.ttf" -Force }
$common=@('--noconfirm','--clean','--onedir','--paths','.','--collect-all','camoufox','--collect-all','flet','--collect-all','flet_desktop','--collect-all','playwright','--collect-all','browserforge','--collect-data','language_tags','--collect-submodules','mcp.server','--collect-submodules','chrome_engine','--add-data','src;src','--add-data','chrome_engine;chrome_engine')
python -m PyInstaller @common --windowed --name FASTBROWSERS --icon src/assets/icon.ico --distpath dist studio_launcher.py
if ($LASTEXITCODE -ne 0) { throw 'GUI build failed' }
python -m PyInstaller @common --console --name FoxProfileWorker --distpath worker-dist studio_worker.py
if ($LASTEXITCODE -ne 0) { throw 'Worker build failed' }
New-Item -ItemType Directory -Path dist/FASTBROWSERS/worker -Force | Out-Null
Copy-Item 'worker-dist/FoxProfileWorker/*' 'dist/FASTBROWSERS/worker' -Force -Recurse
$runtime=(python -c 'from camoufox.pkgman import INSTALL_DIR; print(INSTALL_DIR)' | Select-Object -Last 1).Trim()
if (!(Test-Path $runtime)) { throw 'Browser runtime missing' }
Copy-Item -LiteralPath $runtime -Destination 'dist/FASTBROWSERS/browser-runtime' -Recurse -Force
& 'dist/FASTBROWSERS/worker/FoxProfileWorker.exe' --self-test
if ($LASTEXITCODE -ne 0) { throw 'Worker self test failed' }
& 'dist/FASTBROWSERS/FASTBROWSERS.exe' --self-test
if ($LASTEXITCODE -ne 0) { throw 'GUI self test failed' }
# True desktop entrypoint startup: process must stay alive, independent of optional port errors
$p=Start-Process -FilePath (Resolve-Path 'dist/FASTBROWSERS/FASTBROWSERS.exe').Path -PassThru
Start-Sleep -Seconds 20
$p.Refresh()
if ($p.HasExited) { throw "App exited immediately ($($p.ExitCode)). See %LOCALAPPDATA%/FoxProfileStudio/logs" }
Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
$iscc="${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
if (-not (Test-Path $iscc)) { throw 'Inno Setup compiler missing' }
& $iscc 'windows/FASTBROWSERS.iss'
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup failed' }
Get-FileHash 'release/FASTBROWSERS-Setup-3.1.0-Win64.exe'

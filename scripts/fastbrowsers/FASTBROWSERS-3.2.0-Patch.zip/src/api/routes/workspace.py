"""Accounts/bookmarks/observed environment, backed by local SQLite + Windows DPAPI."""
from __future__ import annotations

import threading
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field, SecretStr

from ...services.profile.workspace import Workspace
from ...services.browser.launcher import BrowserControlError, ProfileBusyError
from ..dependencies import get_browser_launcher, get_profile_manager, get_event_bus
from ..helpers import require_profile

router = APIRouter(tags=["workspace"])

class BookmarkIn(BaseModel):
    profile: str
    label: str = Field(min_length=1, max_length=150)
    url: str = Field(max_length=2048)
    category: str = Field(default="", max_length=80)

class AccountIn(BaseModel):
    profile: str
    service: str = Field(min_length=1, max_length=100)
    label: str = Field(min_length=1, max_length=150)
    username: str = Field(min_length=1, max_length=250)
    url: str = Field(max_length=2048)
    note: str = Field(default="", max_length=1000)
    password: SecretStr | None = None


def _open_bound_account(account:dict, pm, bl) -> None:
    """Open in the linked persistent profile; never switch profile identities."""
    store=Workspace()
    p=pm.profiles.get(account['profile'])
    if p is None:
        store.activity('account_open_error', account['profile'], 'Profile no longer exists')
        return
    try:
        if not bl.is_running(p.name):
            result = bl.start_thread(p, lambda msg: None)
            if not result and not bl.is_running(p.name):
                raise RuntimeError('Browser not started')
            if result:
                ok,err=bl.wait_for_launch(p.name, 90)
                if not ok:
                    raise RuntimeError(err or 'Browser launch timed out')
        bl.control(p.name, 'tab_new', {'url': account['url']}, timeout=35)
        store.activity('account_opened',p.name,account['service'])
    except Exception as exc:
        store.activity('account_open_error',p.name,str(exc)[:240])


@router.get('/workspace/dashboard')
def dashboard(pm=Depends(get_profile_manager), bl=Depends(get_browser_launcher)):
    profiles=pm.list_profiles()
    reports=Workspace().list_audits()
    store=Workspace()
    return {
      'profiles':len(profiles), 'running':len(bl.running_profile_names()),
      'proxy':sum(bool(p.proxy) for p in profiles),
      'engines':{k:sum(p.engine==k for p in profiles) for k in ('camoufox','chrome','edge','coccoc','brave')},
      'accounts':len(store.list_accounts()), 'bookmarks':len(store.list_bookmarks()),
      'checked':sum(r['status']=='checked' for r in reports),
      'failed_checks':sum(r['status']=='error' for r in reports),
    }

@router.get('/workspace/environment')
def environment():
    return Workspace().list_audits()

@router.get('/workspace/activity')
def activity():
    return Workspace().recent_activity()

@router.get('/workspace/bookmarks')
def bookmarks(profile: str | None = None):
    return Workspace().list_bookmarks(profile)

@router.post('/workspace/bookmarks',status_code=201)
def bookmark_add(body: BookmarkIn, pm=Depends(get_profile_manager)):
    require_profile(body.profile,pm)
    try:
        return Workspace().add_bookmark(**body.model_dump())
    except ValueError as exc:
        raise HTTPException(400,str(exc)) from exc

@router.delete('/workspace/bookmarks/{item_id}')
def bookmark_delete(item_id:str):
    if not Workspace().delete_bookmark(item_id):
        raise HTTPException(404,'Bookmark not found')
    return {'ok':True}

@router.post('/workspace/bookmarks/from-current/{profile}',status_code=201)
def bookmark_current(profile:str,pm=Depends(get_profile_manager),bl=Depends(get_browser_launcher)):
    require_profile(profile,pm)
    if not bl.is_running(profile):
        raise HTTPException(409,'Profile is not running')
    try:
        tabs=bl.control(profile,'tabs',{},timeout=12).get('tabs',[])
        active=next((x for x in tabs if x.get('active')),tabs[0] if tabs else None)
        if not active:
            raise HTTPException(409,'No tab is open')
        return Workspace().add_bookmark(profile,active.get('title') or 'Bookmark',active.get('url') or '')
    except (ValueError,BrowserControlError) as exc:
        raise HTTPException(400,str(exc)) from exc

@router.post('/workspace/bookmarks/{item_id}/open',status_code=202)
def bookmark_open(item_id:str,pm=Depends(get_profile_manager),bl=Depends(get_browser_launcher)):
    item=next((x for x in Workspace().list_bookmarks() if x['id']==item_id),None)
    if item is None:
        raise HTTPException(404,'Bookmark not found')
    require_profile(item['profile'],pm)
    threading.Thread(target=_open_bound_account,args=(item,pm,bl),daemon=True).start()
    return {'message':'Opening bookmark in linked browser profile','profile':item['profile']}

@router.get('/workspace/accounts')
def accounts(profile: str | None = None):
    return Workspace().list_accounts(profile)

@router.post('/workspace/accounts',status_code=201)
def account_add(body:AccountIn,pm=Depends(get_profile_manager)):
    require_profile(body.profile,pm)
    try:
        values=body.model_dump(exclude={'password'})
        values['password']=body.password.get_secret_value() if body.password else ''
        return Workspace().add_account(**values)
    except (ValueError,RuntimeError,OSError) as exc:
        raise HTTPException(400,str(exc)) from exc

@router.delete('/workspace/accounts/{account_id}')
def account_delete(account_id:str):
    if not Workspace().delete_account(account_id):
        raise HTTPException(404,'Account not found')
    return {'ok':True}

@router.post('/workspace/accounts/{account_id}/open',status_code=202)
def account_open(account_id:str,pm=Depends(get_profile_manager),bl=Depends(get_browser_launcher)):
    account=Workspace().get_account(account_id)
    if account is None:
        raise HTTPException(404,'Account not found')
    require_profile(account['profile'],pm)
    threading.Thread(target=_open_bound_account,args=(account,pm,bl),daemon=True).start()
    return {'message':'Opening saved account in linked profile','profile':account['profile']}

@router.post('/workspace/accounts/{account_id}/fill')
def account_fill(account_id:str,pm=Depends(get_profile_manager),bl=Depends(get_browser_launcher)):
    """Explicit user action only. Fill login form without submitting it."""
    store=Workspace()
    account=store.get_account(account_id)
    if account is None:
        raise HTTPException(404,'Account not found')
    profile=account['profile']
    require_profile(profile,pm)
    if not bl.is_running(profile):
        raise HTTPException(409,'Open the linked profile first')
    domain=urlparse(account['url']).hostname or ''
    if domain not in ('facebook.com','www.facebook.com','m.facebook.com'):
        raise HTTPException(400,'Auto-fill is currently supported only on Facebook')
    try:
        page_info=bl.control(profile,'evaluate',{'script':'() => window.location.hostname'},timeout=10)
        current=str(page_info.get('result','')).lower()
        if current not in ('facebook.com','www.facebook.com','m.facebook.com'):
            raise HTTPException(400,'Open Facebook in this profile before filling credentials')
        bl.control(profile,'type',{'selector':'input[name="email"]','text':account['username'],'submit':False},timeout=15)
        secret=store.decrypt_password(account_id)
        if secret:
            bl.control(profile,'type',{'selector':'input[name="pass"]','text':secret,'submit':False},timeout=15)
        store.activity('credentials_filled',profile,'Facebook login form; submit manually')
        return {'message':'Filled Facebook login form; review and submit manually','password_saved':bool(secret)}
    except BrowserControlError as exc:
        raise HTTPException(exc.status,str(exc)) from exc

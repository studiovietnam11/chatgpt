"""Local FASTBROWSERS workspace: bookmarks, named accounts and launch audits.

Passwords are protected with the *current Windows user's* DPAPI key; no
plaintext password is written into JSON, SQLite or application logs.
This is an app-local organizer, not a cloud-synchronised password manager.
"""
from __future__ import annotations

import ctypes
import hashlib
import ctypes.wintypes
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

from ...core.config import PROFILES_FILE, DATA_DIR

MAX_BOOKMARKS = 10000
MAX_ACCOUNTS = 10000
_ALLOWED = {"http", "https"}


def safe_url(url: str) -> str:
    if not isinstance(url, str) or len(url) > 2048:
        raise ValueError("Invalid URL")
    item = urlparse(url.strip())
    if item.scheme not in _ALLOWED or not item.hostname or item.username or item.password:
        raise ValueError("Only normal http/https URLs without credentials are allowed")
    if item.hostname.lower() in {"localhost", "127.0.0.1", "::1"}:
        raise ValueError("Local-host addresses are not saved as account destinations")
    return url.strip()


class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _dpapi(data: bytes, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Saving passwords requires Windows DPAPI")
    # CryptProtectData / CryptUnprotectData on the current Windows account.
    src = ctypes.create_string_buffer(data)
    input_blob = _BLOB(len(data), ctypes.cast(src, ctypes.POINTER(ctypes.c_byte)))
    output_blob = _BLOB()
    crypt = ctypes.windll.crypt32
    fn = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    ctypes.windll.kernel32.SetLastError(0)
    if decrypt:
        ok = fn(ctypes.byref(input_blob), None, None, None, None, 0x01, ctypes.byref(output_blob))
    else:
        ok = fn(ctypes.byref(input_blob), ctypes.c_wchar_p("FASTBROWSERS local account"), None, None, None, 0x01, ctypes.byref(output_blob))
    if not ok:
        raise OSError("Windows credential encryption failed")
    try:
        return ctypes.string_at(output_blob.pbData, output_blob.cbData)
    finally:
        local_free = ctypes.windll.kernel32.LocalFree
        local_free.argtypes = [ctypes.c_void_p]
        local_free.restype = ctypes.c_void_p
        local_free(ctypes.cast(output_blob.pbData, ctypes.c_void_p))


class Workspace:
    """Short-lived SQLite connections allow use from UI, FastAPI and worker threads."""

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else Path(PROFILES_FILE).resolve().parent / "fastbrowsers-workspace.sqlite3"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        with self._connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS bookmarks (
                id TEXT PRIMARY KEY, profile TEXT NOT NULL, label TEXT NOT NULL,
                url TEXT NOT NULL, category TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_bookmark_profile ON bookmarks(profile);
            CREATE TABLE IF NOT EXISTS accounts (
                id TEXT PRIMARY KEY, service TEXT NOT NULL, label TEXT NOT NULL,
                username TEXT NOT NULL, url TEXT NOT NULL, profile TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT '', password_blob BLOB, created_at REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_account_profile ON accounts(profile);
            CREATE TABLE IF NOT EXISTS audits (
                profile TEXT PRIMARY KEY, status TEXT NOT NULL, started_at REAL NOT NULL,
                completed_at REAL, exit_ip TEXT, proxy_enabled INTEGER NOT NULL DEFAULT 0,
                browser_engine TEXT, user_agent TEXT, platform TEXT, language TEXT,
                timezone TEXT, cpu_cores INTEGER, screen TEXT, device_id TEXT, webgl TEXT, error TEXT);
            CREATE TABLE IF NOT EXISTS activity (
                id TEXT PRIMARY KEY, happened_at REAL NOT NULL, type TEXT NOT NULL,
                profile TEXT NOT NULL, detail TEXT NOT NULL);
            """)
            # Non-destructive schema upgrade for databases created by earlier builds.
            names={r[1] for r in c.execute("PRAGMA table_info(audits)")}
            for field in ("device_id", "webgl"):
                if field not in names:
                    c.execute(f"ALTER TABLE audits ADD COLUMN {field} TEXT")

    def _connect(self):
        c = sqlite3.connect(self.path, timeout=8)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA busy_timeout=8000")
        return c

    def activity(self, kind: str, profile: str, detail: str = "") -> None:
        with self._lock, self._connect() as c:
            c.execute("INSERT INTO activity VALUES (?,?,?,?,?)",
                      (uuid.uuid4().hex, time.time(), kind[:60], profile[:100], detail[:300]))
            c.execute("DELETE FROM activity WHERE id IN (SELECT id FROM activity ORDER BY happened_at DESC LIMIT -1 OFFSET 2000)")

    def recent_activity(self, limit: int = 80):
        with self._lock, self._connect() as c:
            return [dict(x) for x in c.execute("SELECT * FROM activity ORDER BY happened_at DESC LIMIT ?", (min(200, max(1, limit)),))]

    def add_bookmark(self, profile: str, label: str, url: str, category: str = "") -> dict:
        url = safe_url(url)
        if not profile or not label.strip() or len(label)>150:
            raise ValueError("Bookmark label and profile are required")
        with self._lock, self._connect() as c:
            if c.execute("SELECT count(*) FROM bookmarks").fetchone()[0] >= MAX_BOOKMARKS:
                raise ValueError("Bookmark limit reached")
            item = {"id": uuid.uuid4().hex, "profile": profile, "label": label.strip(),
                    "url": url, "category": category.strip()[:80], "created_at": time.time()}
            c.execute("INSERT INTO bookmarks VALUES (:id,:profile,:label,:url,:category,:created_at)", item)
            return item

    def list_bookmarks(self, profile: str | None = None) -> list[dict]:
        with self._lock, self._connect() as c:
            if profile:
                rows=c.execute("SELECT * FROM bookmarks WHERE profile=? ORDER BY created_at DESC",(profile,))
            else:
                rows=c.execute("SELECT * FROM bookmarks ORDER BY created_at DESC LIMIT 2000")
            return [dict(r) for r in rows]

    def delete_bookmark(self, item_id: str) -> bool:
        with self._lock, self._connect() as c:
            return c.execute("DELETE FROM bookmarks WHERE id=?",(item_id,)).rowcount>0

    def add_account(self, service: str, label: str, username: str, url: str,
                    profile: str, password: str = "", note: str = "") -> dict:
        url = safe_url(url)
        if not profile or not service.strip() or not label.strip() or not username.strip():
            raise ValueError("Service, label, username and profile are required")
        if len(username)>250 or len(label)>150 or len(note)>1000 or len(password)>4096:
            raise ValueError("Account field too long")
        if password and urlparse(url).scheme != "https":
            raise ValueError("Password-managed accounts require an HTTPS login URL")
        encrypted = _dpapi(password.encode("utf-8")) if password else None
        with self._lock, self._connect() as c:
            if c.execute("SELECT count(*) FROM accounts").fetchone()[0] >= MAX_ACCOUNTS:
                raise ValueError("Account limit reached")
            item={"id":uuid.uuid4().hex,"service":service.strip()[:100],"label":label.strip(),
                  "username":username.strip(),"url":url,"profile":profile,"note":note.strip(),
                  "password_blob":encrypted,"created_at":time.time()}
            c.execute("""INSERT INTO accounts (id,service,label,username,url,profile,note,password_blob,created_at)
                         VALUES (:id,:service,:label,:username,:url,:profile,:note,:password_blob,:created_at)""", item)
        self.activity("account_saved",profile,item["service"])
        return self._public_account(item)

    @staticmethod
    def _public_account(item: dict) -> dict:
        return {key:val for key,val in item.items() if key != "password_blob"} | {"password_saved": bool(item.get("password_blob"))}

    def list_accounts(self, profile: str | None = None) -> list[dict]:
        with self._lock, self._connect() as c:
            if profile:
                rows=c.execute("SELECT * FROM accounts WHERE profile=? ORDER BY created_at DESC",(profile,))
            else:
                rows=c.execute("SELECT * FROM accounts ORDER BY created_at DESC LIMIT 2000")
            return [self._public_account(dict(r)) for r in rows]

    def get_account(self, account_id: str) -> dict | None:
        with self._lock, self._connect() as c:
            item=c.execute("SELECT * FROM accounts WHERE id=?",(account_id,)).fetchone()
            return dict(item) if item else None

    def delete_account(self, account_id: str) -> bool:
        with self._lock, self._connect() as c:
            row = c.execute("SELECT profile FROM accounts WHERE id=?",(account_id,)).fetchone()
            result = c.execute("DELETE FROM accounts WHERE id=?",(account_id,)).rowcount>0
        if row and result:
            self.activity("account_deleted", row["profile"])
        return result

    def decrypt_password(self, account_id: str) -> str:
        item = self.get_account(account_id)
        if not item or item["password_blob"] is None:
            return ""
        return _dpapi(item["password_blob"], decrypt=True).decode("utf-8")

    def start_audit(self, profile: str, engine: str, proxy_enabled: bool) -> None:
        with self._lock, self._connect() as c:
            c.execute("""INSERT INTO audits (profile,status,started_at,proxy_enabled,browser_engine)
                         VALUES (?,?,?,?,?) ON CONFLICT(profile) DO UPDATE SET status=excluded.status,
                         started_at=excluded.started_at, completed_at=NULL, error=NULL,
                         proxy_enabled=excluded.proxy_enabled,browser_engine=excluded.browser_engine""",
                      (profile,"checking",time.time(),int(proxy_enabled),engine))
        self.activity("browser_launch",profile,engine)

    def finish_audit(self, profile: str, result: dict | None, error: str = "") -> None:
        result=result or {}
        if not error and not result.get("ip"):
            error = str(result.get("ipError") or "Public IP was not verified")
        with self._lock, self._connect() as c:
            fp = Path(DATA_DIR) / profile / "fingerprint.json"
            device_id = None
            try:
                if fp.is_file():
                    device_id = hashlib.sha256(fp.read_bytes()).hexdigest()[:16]
            except OSError:
                pass
            c.execute("""UPDATE audits SET status=?,completed_at=?,exit_ip=?,user_agent=?,platform=?,language=?,
                         timezone=?,cpu_cores=?,screen=?,device_id=?,webgl=?,error=? WHERE profile=?""",
                      ("error" if error else "checked",time.time(),str(result.get("ip") or "")[:100],
                       str(result.get("userAgent") or "")[:350],str(result.get("platform") or "")[:100],
                       str(result.get("language") or "")[:100],str(result.get("timezone") or "")[:100],
                       result.get("cpu"),str(result.get("screen") or "")[:80],device_id,
                       str(result.get("webgl") or "")[:280],error[:500],profile))
        self.activity("environment_error" if error else "environment_checked",profile,error[:200] or str(result.get("ip") or ""))

    def rename_profile(self, old: str, new: str) -> None:
        if old == new:
            return
        with self._lock, self._connect() as c:
            for table in ("bookmarks", "accounts", "audits", "activity"):
                c.execute(f"UPDATE {table} SET profile=? WHERE profile=?", (new, old))

    def list_audits(self) -> list[dict]:
        with self._lock, self._connect() as c:
            return [dict(x) for x in c.execute("SELECT * FROM audits ORDER BY started_at DESC LIMIT 1000")]

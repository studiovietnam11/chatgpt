"""FASTBROWSERS 3.2 modular professional workspace.

The dashboard is not a scrolling mix of unrelated modules: each function has
its own real navigation tab, populated from live data and independent actions.
"""
from __future__ import annotations
import flet as ft
from ..theme.colors import COLORS, FONT_BOLD, FONT_SEMIBOLD

C = COLORS
NAV = (
    ("overview", "Tổng quan", ft.Icons.DASHBOARD_OUTLINED),
    ("profiles", "Browser Profiles", ft.Icons.VIEW_LIST_OUTLINED),
    ("engines", "Browser Engines", ft.Icons.WEB_OUTLINED),
    ("network", "Network & IP", ft.Icons.SHIELD_OUTLINED),
    ("bookmarks", "Bookmarks", ft.Icons.BOOKMARK_BORDER),
    ("accounts", "Accounts & Login", ft.Icons.PEOPLE_OUTLINE),
    ("activity", "Activity Logs", ft.Icons.HISTORY),
)


def label(name, size=14, color=None):
    return ft.Text(name, size=size, color=color or C['text_main'], font_family=FONT_SEMIBOLD,
                   weight=ft.FontWeight.W_600)


def card(content, padding=20):
    return ft.Container(bgcolor=C['card_bg'],border=ft.Border.all(1,C['card_border']),
                        border_radius=13,padding=padding,content=content)


def stat(label_text, data, glyph, hint=""):
    data.size = 28
    data.font_family = FONT_BOLD
    data.color = C['text_main']
    return ft.Container(expand=True,content=card(ft.Column(spacing=7,controls=[
        ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[
            ft.Text(label_text,size=12,color=C['text_sub']),
            ft.Icon(glyph,color=C['accent'],size=20)]),
        data,
        ft.Text(hint,size=10.5,color=C['text_dim']),
    ])))


def section(title, subtext, content):
    return ft.Column(spacing=11,controls=[
        ft.Row(spacing=12,controls=[label(title,16), ft.Text(subtext,size=11,color=C['text_dim'])]),
        content,
    ])


def build_content_area(
    subtitle: ft.Text, profile_list: ft.Column, prev_btn: ft.IconButton,
    next_btn: ft.IconButton, page_label: ft.Text,
    bulk_bar: ft.Control | None = None, search_field: ft.Control | None = None,
    header_slot: ft.Container | None = None,
    metrics: tuple[ft.Text,...] | None = None,
    engine_inventory: ft.Text | None = None,
    environment_text: ft.Text | None = None,
    proxy_text: ft.Text | None = None,
    on_random_profile=None,on_new_profile=None,
    accounts_list:ft.Column|None=None,bookmarks_list:ft.Column|None=None,
    audits_list:ft.Column|None=None,activity_list:ft.Column|None=None,
    on_add_account=None,on_add_bookmark=None,on_refresh_workspace=None,
) -> ft.Container:
    metrics = metrics or tuple(ft.Text('0') for _ in range(8))
    accounts_list = accounts_list or ft.Column()
    bookmarks_list = bookmarks_list or ft.Column()
    audits_list = audits_list or ft.Column()
    activity_list = activity_list or ft.Column()
    engine_inventory = engine_inventory or ft.Text('Chưa có engine')
    environment_text = environment_text or ft.Text('Chưa có thông tin')
    proxy_text = proxy_text or ft.Text('Chưa có kết nối')
    for t in (engine_inventory, environment_text, proxy_text):
        t.size=12.5
        t.color=C['text_sub']

    header = ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[
        ft.Column(spacing=4,controls=[
            ft.Text('FASTBROWSERS  /  WORKSPACE',size=10.5,color=C['accent'],weight=ft.FontWeight.W_700),
            label('Quản trị trình duyệt',size=25),
            ft.Text('Dữ liệu trực tiếp từ máy • Quản lý profile, mạng và tài khoản tại một nơi',size=12.2,color=C['text_sub']),
        ]),
        ft.Row(spacing=10,controls=[
            ft.OutlinedButton('Tạo ngẫu nhiên',icon=ft.Icons.CASINO_OUTLINED,on_click=on_random_profile),
            ft.Button('Tạo profile',icon=ft.Icons.ADD,on_click=on_new_profile,
                      style=ft.ButtonStyle(bgcolor=C['accent'],color='#FFFFFF')),
        ])
    ])

    sheet = card(ft.Column(spacing=0,controls=[
        *([bulk_bar] if bulk_bar is not None else []),
        *([header_slot] if header_slot is not None else []),
        profile_list,
    ]), padding=0)

    overview = ft.Column(spacing=18,controls=[
        section('Tổng quan hoạt động','Các chỉ số từ profile thực tế',
                ft.Row(spacing=12,controls=[
                    stat('Tổng profile',metrics[0],ft.Icons.LAYERS_OUTLINED,'Đã tạo trên máy'),
                    stat('Đang chạy',metrics[1],ft.Icons.PLAY_CIRCLE_OUTLINE,'Phiên trình duyệt đang mở'),
                    stat('Đã dừng',metrics[2],ft.Icons.PAUSE_CIRCLE_OUTLINE,'Có thể khởi chạy'),
                    stat('Có proxy',metrics[3],ft.Icons.SHIELD_OUTLINED,'Kết nối đã cấu hình'),
                ])),
        section('Phân bổ môi trường','Không tính trùng profile',ft.Row(spacing=12,controls=[
            stat('Camoufox',metrics[4],ft.Icons.PUBLIC),
            stat('Chromium & browser khác',metrics[5],ft.Icons.WEB_OUTLINED),
            stat('Tổ hợp hệ điều hành',metrics[6],ft.Icons.COMPUTER_OUTLINED),
            stat('Nhóm thiết bị',metrics[7],ft.Icons.DEVICES_OUTLINED),
        ])),
        section('Sức khỏe hệ thống','Các mục chi tiết có tab riêng',ft.Row(spacing=12,controls=[
            ft.Container(expand=True,content=card(ft.Column(spacing=12,controls=[label('Engine đang quản lý'),engine_inventory]))),
            ft.Container(expand=True,content=card(ft.Column(spacing=12,controls=[label('Hệ điều hành & thiết bị'),environment_text]))),
            ft.Container(expand=True,content=card(ft.Column(spacing=12,controls=[label('Kết nối mạng'),proxy_text]))),
        ])),
    ])
    profile_toolbar=ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[
        ft.Column(spacing=3,controls=[label('Danh sách browser profiles',17),subtitle]),
        ft.Row(spacing=10,controls=[
            *([search_field] if search_field is not None else []),
            ft.OutlinedButton('Tạo ngẫu nhiên',icon=ft.Icons.CASINO_OUTLINED,on_click=on_random_profile),
        ]),
    ])
    profiles = ft.Column(spacing=14,controls=[profile_toolbar,sheet,
        ft.Row(alignment=ft.MainAxisAlignment.END,controls=[prev_btn,page_label,next_btn])])
    engines=ft.Column(spacing=18,controls=[
        section('Browser Engines','Tình trạng runtime trên máy',card(ft.Column(spacing=12,controls=[
            label('Các trình duyệt khả dụng',16),engine_inventory,
            ft.Divider(height=1,color=C['card_border']),
            ft.Text('Camoufox dùng runtime đóng gói; Edge, Cốc Cốc và Brave yêu cầu cài trên Windows. '
                    'Khả năng fingerprint phụ thuộc engine.',size=12,color=C['text_sub'])]))),
        section('Phân bổ engine','Thống kê theo profile',ft.Row(spacing=12,controls=[
            stat('Camoufox',metrics[4],ft.Icons.PUBLIC),stat('Chromium + trình duyệt khác',metrics[5],ft.Icons.WEB_OUTLINED)])),
    ])
    network=ft.Column(spacing=18,controls=[
        section('Network & IP','Quan sát thực tế sau khi khởi động trình duyệt',card(ft.Column(spacing=10,controls=[
            label('Kết quả kiểm tra phiên',15),
            ft.Text('IP công khai được kiểm tra từ trong chính browser profile. '
                    'Nếu dịch vụ IP không phản hồi, trạng thái sẽ báo chưa xác minh thay vì suy đoán.',
                    size=12,color=C['text_sub']),
            audits_list,
        ]))),
        section('Proxy coverage','Thống kê cấu hình kết nối',card(proxy_text)),
    ])
    bookmark_panel=ft.Column(spacing=16,controls=[
        ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[
            ft.Column(spacing=4,controls=[label('Bookmark Library',20),
                ft.Text('Lưu URL theo từng profile • Một cú nhấp mở lại đúng browser',size=12,color=C['text_sub'])]),
            ft.Button('Thêm bookmark',icon=ft.Icons.BOOKMARK_ADD_OUTLINED,on_click=on_add_bookmark),
        ]),card(bookmarks_list),
    ])
    account_panel=ft.Column(spacing=16,controls=[
        ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[
            ft.Column(spacing=4,controls=[label('Accounts & Login',20),
                ft.Text('Tài khoản liên kết profile • Mật khẩu tùy chọn được mã hóa bằng Windows',size=12,color=C['text_sub'])]),
            ft.Button('Thêm tài khoản',icon=ft.Icons.PERSON_ADD_ALT_1,on_click=on_add_account),
        ]),
        card(ft.Column(spacing=10,controls=[
            ft.Row(spacing=8,controls=[ft.Icon(ft.Icons.LOCK_OUTLINE,size=17,color=C['success']),
                ft.Text('Không sao chép cookie giữa các profile. Lưu phiên đăng nhập trong profile gốc.',size=12,color=C['text_sub'])]),
            accounts_list,
        ])),
    ])
    activity=ft.Column(spacing=15,controls=[
        ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[label('Activity Logs',20),
            ft.OutlinedButton('Làm mới',icon=ft.Icons.REFRESH,on_click=on_refresh_workspace)]),
        card(activity_list),
    ])
    panels={"overview":overview,"profiles":profiles,"engines":engines,"network":network,
            "bookmarks":bookmark_panel,"accounts":account_panel,"activity":activity}
    nav_buttons={}
    holders={key:ft.Container(content=body,visible=key=='overview') for key,body in panels.items()}

    def select(key):
        for k,pane in holders.items():
            pane.visible = k==key
        for k,node in nav_buttons.items():
            selected = k==key
            node.bgcolor = C['accent_soft'] if selected else '#FFFFFF'
            node.border=ft.Border.all(1,C['accent'] if selected else C['card_border'])
            row=node.content
            if isinstance(row, ft.Row):
                row.controls[0].color=C['accent'] if selected else C['text_sub']
                row.controls[1].color=C['accent'] if selected else C['text_sub']
        if on_refresh_workspace and key in ('accounts','bookmarks','network','activity'):
            on_refresh_workspace()
        main.update()

    for key,name,glyph in NAV:
        nav_buttons[key]=ft.Container(
            border_radius=9,padding=ft.Padding.symmetric(horizontal=11,vertical=11),
            bgcolor=C['accent_soft'] if key=='overview' else C['card_bg'],
            border=ft.Border.all(1,C['accent'] if key=='overview' else C['card_border']),
            ink=True,on_click=lambda _,k=key:select(k),
            content=ft.Row(spacing=7,controls=[
                ft.Icon(glyph,size=16,color=C['accent'] if key=='overview' else C['text_sub']),
                ft.Text(name,size=12.2,color=C['accent'] if key=='overview' else C['text_sub'],
                        weight=ft.FontWeight.W_600),
            ]))
    nav = ft.Row(spacing=8,scroll=ft.ScrollMode.AUTO,controls=list(nav_buttons.values()))
    main=ft.Container(expand=True,bgcolor=C['bg'],
        padding=ft.Padding.only(left=29,right=29,top=23,bottom=15),
        content=ft.Column(expand=True,scroll=ft.ScrollMode.AUTO,spacing=18,controls=[
            header,
            ft.Container(content=nav,padding=ft.Padding.only(top=9,bottom=5)),
            *holders.values(),ft.Container(height=15),
        ]))
    return main

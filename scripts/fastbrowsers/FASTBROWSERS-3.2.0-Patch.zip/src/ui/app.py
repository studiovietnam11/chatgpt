import asyncio
import datetime
import threading
from urllib.parse import urlparse
from collections import Counter
import os
import time

import flet as ft

from ..core.config import DATA_DIR
from ..core.container import Container
from ..core.logging import get_logger
from ..core.strings import current_language, get_string, set_language
from ..interfaces.protocols import IBrowserLauncher, IProfileManager, IProxyService
from ..services.browser import fingerprint
from ..services.browser.environment import inventory
from ..services.profile.workspace import Workspace
from .components import (
    build_content_area,
    build_empty_state,
    build_profile_card,
    build_sidebar,
    build_ui_refs,
    rebuild_bulk_bar,
)
from .components.profile_card import build_header_row
from .components.sidebar import build_filter_buttons
from .dialogs.mcp_guide import open_mcp_guide
from .handlers import AppHandlers
from .refs import UIRefs
from .state import ITEMS_PER_PAGE, AppState
from .theme import COLORS, configure_page
from .theme.colors import FONT_SEMIBOLD
from .theme.page import ASSETS_DIR

logger = get_logger("app")


class App:
    def __init__(self, container: Container | None = None) -> None:
        c = container or Container()
        self.pm: IProfileManager = c.profile_manager
        self.bl: IBrowserLauncher = c.browser_launcher
        self.ps: IProxyService = c.proxy_service
        self.state = AppState()
        self.workspace = Workspace()
        self.page: ft.Page | None = None
        self._reconcile_started = False
        self.refs: UIRefs | None = None
        self.filter = "all"
        self._live_since: dict[str, str] = {}
        self._filter_column = ft.Column(spacing=2)
        self._header_slot = ft.Container()
        c.event_bus.subscribe(self.state.schedule_refresh)
        self.h = AppHandlers(
            pm=self.pm,
            bl=self.bl,
            ps=self.ps,
            state=self.state,
            get_page=lambda: self.page,
            get_refs=lambda: self.refs,
            log_fn=self._log,
            refresh_fn=self._refresh_profiles,
            get_page_profiles=self._get_page_profiles,
        )

    def run(self) -> None:
        ft.run(self._main, assets_dir=ASSETS_DIR)

    def _main(self, page: ft.Page) -> None:
        self.page = page
        configure_page(page)
        fp = ft.FilePicker()
        page.services.append(fp)
        self.clipboard = ft.Clipboard()
        page.services.append(self.clipboard)
        self._file_picker = fp
        self._build_ui()
        self.state._last_running_snapshot = self.bl.running_profile_names()
        if not self._reconcile_started:
            self._reconcile_started = True
            page.run_task(self._ui_reconcile_loop)

    def _build_ui(self) -> None:
        """(Re)build every control; strings are read at build time."""
        assert self.page is not None
        self.refs = build_ui_refs(
            pm=self.pm,
            on_change_page=self._change_page,
            file_picker=self._file_picker,
            on_search=self._on_search,
        )
        self._filter_column = ft.Column(spacing=2)
        self._header_slot = ft.Container()
        self._metric_texts = tuple(ft.Text("0") for _ in range(8))
        self._accounts_list = ft.Column(spacing=0)
        self._bookmarks_list = ft.Column(spacing=0)
        self._audits_list = ft.Column(spacing=0)
        self._activity_list = ft.Column(spacing=0)
        self._engine_inventory = ft.Text("Đang kiểm tra engine...", size=11.5, color=COLORS["text_sub"])
        self._environment_text = ft.Text("Đang tổng hợp môi trường...",size=11.5,color=COLORS["text_sub"])
        self._proxy_text = ft.Text("Đang tổng hợp proxy...",size=11.5,color=COLORS["text_sub"])
        self.page.title = get_string("window_title")
        self.page.controls.clear()
        self.page.add(self._build_root_layout(self.refs))
        self._restore_log()
        self._refresh_profiles()
        self._refresh_workspace_ui()

    def _restore_log(self) -> None:
        """Refill a freshly built log pane (flush_log only returns new lines)."""
        r = self.refs
        assert r is not None
        lines = self.state.get_all_log_lines()[-6:]
        r.log_text.value = "\n".join(lines)
        r.log_column.height = max(72, len(lines) * 18 + 20)
        r.log_column.visible = bool(lines) and not self.state.log_collapsed
        r.log_toggle_btn.icon = (
            ft.Icons.KEYBOARD_ARROW_RIGHT
            if self.state.log_collapsed
            else ft.Icons.KEYBOARD_ARROW_DOWN
        )

    def _set_language(self, code: str) -> None:
        if code == current_language():
            return
        set_language(code)
        self.state.search_query = ""
        self._build_ui()

    def _build_root_layout(self, r: UIRefs) -> ft.Row:
        sidebar = build_sidebar(
            r.stats_text,
            r.running_text,
            r.log_text,
            r.log_column,
            r.log_toggle_btn,
            on_new_profile=lambda _: self.h.open_add_dialog(),
            on_random_profile=lambda _: self.h.create_random_now(),
            on_import=self.h.on_import,
            on_export=lambda _: self.h.on_export_open(),
            on_mcp=lambda _: open_mcp_guide(self.page, self.clipboard),
            on_toggle_log=lambda _: self.h.toggle_log(),
            on_fullscreen_log=lambda _: self.h.open_log_fullscreen(),
            filter_column=self._filter_column,
            language=current_language(),
            on_language=self._set_language,
        )
        content = build_content_area(
            r.content_subtitle,
            r.profile_list_area,
            r.prev_btn,
            r.next_btn,
            r.page_label,
            r.bulk_bar,
            r.search_field,
            header_slot=self._header_slot,
            metrics=self._metric_texts,
            engine_inventory=self._engine_inventory,
            environment_text=self._environment_text,
            proxy_text=self._proxy_text,
            on_random_profile=lambda _: self.h.create_random_now(),
            on_new_profile=lambda _: self.h.open_add_dialog(),
            accounts_list=self._accounts_list,bookmarks_list=self._bookmarks_list,
            audits_list=self._audits_list,activity_list=self._activity_list,
            on_add_account=lambda _: self._account_dialog(),
            on_add_bookmark=lambda _: self._bookmark_dialog(),
            on_refresh_workspace=lambda _: self._refresh_workspace_ui(),
        )
        return ft.Row(
            expand=True,
            spacing=0,
            controls=[
                sidebar,
                content,
            ],
        )

    def _on_search(self, query: str) -> None:
        self.state.search_query = query.strip().lower()
        self.state.current_page = 1
        self._refresh_profiles()

    def _on_filter(self, fid: str) -> None:
        self.filter = fid
        self.state.current_page = 1
        self._refresh_profiles()

    def _filter_tests(self) -> dict:
        return {
            "all": lambda p: True,
            "running": lambda p: self.bl.is_running(p.name),
            "proxy": lambda p: bool(p.proxy),
            "direct": lambda p: not p.proxy,
            "chrome": lambda p: p.engine == "chrome",
        }

    def _get_page_profiles(self) -> tuple[list, list, int]:
        all_profiles = self.pm.list_profiles()
        test = self._filter_tests().get(self.filter, lambda p: True)
        all_profiles = [p for p in all_profiles if test(p)]
        if q := self.state.search_query:
            all_profiles = [
                p for p in all_profiles if q in p.name.lower() or q in (p.proxy or "").lower()
            ]
        total = max(1, (len(all_profiles) + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE)
        self.state.current_page = min(self.state.current_page, total)
        start = (self.state.current_page - 1) * ITEMS_PER_PAGE
        return all_profiles, all_profiles[start : start + ITEMS_PER_PAGE], total

    def _refresh_profiles(self) -> None:
        r = self.refs
        assert r is not None
        self._update_stats()
        self._flush_log()
        all_profiles, page_profiles, total_pages = self._get_page_profiles()

        all_names = set(self.pm.profiles)
        for stale in self.state.selected_names() - all_names:
            self.state.toggle_selection(stale)

        running = self.bl.running_profile_names()
        # A failure mark lasts until the profile runs again or is gone.
        self.state.failed.intersection_update(all_names - running)
        for name in running - set(self._live_since):
            self._live_since[name] = time.strftime("%H:%M")
        for name in set(self._live_since) - running:
            del self._live_since[name]

        everything = self.pm.list_profiles()
        tests = self._filter_tests()
        self._filter_column.controls = build_filter_buttons(
            self.filter,
            {fid: sum(1 for p in everything if test(p)) for fid, test in tests.items()},
            self._on_filter,
        )
        names = [p.name for p in page_profiles]
        all_sel = bool(names) and all(self.state.is_selected(n) for n in names)
        any_sel = any(self.state.is_selected(n) for n in names)
        self._header_slot.content = (
            build_header_row(
                all_sel,
                any_sel,
                lambda select: self.h.on_select_all_page() if select else self.h.on_deselect_page(),
            )
            if page_profiles
            else None
        )

        r.profile_list_area.controls = (
            [
                build_profile_card(
                    p,
                    self.state.is_loading(p.name),
                    self.bl.is_running(p.name),
                    self.h.on_launch,
                    self.h.on_edit,
                    self.h.on_delete,
                    is_selected=self.state.is_selected(p.name),
                    on_select=self.h.on_toggle_select,
                    on_cookies=self.h.on_cookies,
                    device=self._device_label(p.name),
                    since=self._live_since.get(p.name, ""),
                    failed=p.name in self.state.failed,
                    on_bookmark=self._bookmark_current_page,
                )
                for p in page_profiles
            ]
            if page_profiles
            else [self._build_empty_or_no_results()]
        )
        rebuild_bulk_bar(
            r.bulk_bar,
            self.state,
            page_profiles,
            {
                "launch": self.h.on_bulk_launch,
                "stop": self.h.on_bulk_stop,
                "delete": self.h.on_bulk_delete,
                "select_page": self.h.on_select_all_page,
                "deselect_page": self.h.on_deselect_page,
                "clear": self.h.on_clear_selection,
            },
        )
        self._set_subtitle(r.content_subtitle)
        r.page_label.value = get_string(
            "page_of",
            current=self.state.current_page,
            total=total_pages,
        )
        r.prev_btn.disabled = self.state.current_page <= 1
        r.next_btn.disabled = self.state.current_page >= total_pages
        self._safe_update()

    @staticmethod
    def _device_label(name: str) -> str:
        info = fingerprint.summary(os.path.join(DATA_DIR, name))
        if not info:
            return ""
        cpu = f"{info['hardware_concurrency']} CPU"
        return f"{info['screen']} · {cpu}" if info.get("screen") else cpu

    def _build_empty_or_no_results(self) -> ft.Control:
        if self.pm.profiles:
            return ft.Container(
                padding=ft.Padding.symmetric(vertical=56, horizontal=24),
                alignment=ft.Alignment(0, 0),
                content=ft.Column(
                    tight=True,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=12,
                    controls=[
                        ft.Text(
                            get_string("no_search_results", query=self.state.search_query)
                            if self.state.search_query
                            else get_string("no_filter_results"),
                            size=14,
                            color=COLORS["text_sub"],
                        ),
                        ft.OutlinedButton(
                            get_string("clear_filters"),
                            on_click=lambda _: self._clear_filters(),
                        ),
                    ],
                ),
            )
        return build_empty_state(lambda _: self.h.open_add_dialog())

    def _clear_filters(self) -> None:
        self.filter = "all"
        self.state.search_query = ""
        if self.refs and self.refs.search_field is not None:
            self.refs.search_field.value = ""
        self._refresh_profiles()

    def _change_page(self, delta: int) -> None:
        self.state.current_page += delta
        self._refresh_profiles()

    def _set_subtitle(self, text: ft.Text) -> None:
        """ "10 profile · 2 đang chạy", the running count in stamp violet."""
        c, r = len(self.pm.profiles), self.bl.running_count()
        head = get_string("profiles_configured", count=c) + " · "
        text.value = None
        text.spans = (
            [
                ft.TextSpan(head),
                ft.TextSpan(str(r), ft.TextStyle(color=COLORS["live"], font_family=FONT_SEMIBOLD)),
                ft.TextSpan(" " + get_string("profiles_running_suffix")),
            ]
            if r
            else [ft.TextSpan(head + get_string("profiles_none_running"))]
        )

    def _update_stats(self) -> None:
        r = self.refs
        if r:
            cnt = self.bl.running_count()
            r.stats_text.value = get_string(
                "total_profiles",
                count=len(self.pm.profiles),
            )
            r.running_text.value = (
                get_string("browsers_running", count=cnt)
                if cnt
                else get_string("no_active_sessions")
            )
            profiles = self.pm.list_profiles()
            configured = len(profiles)
            with_proxy = sum(bool(p.proxy) for p in profiles)
            values = [configured, cnt, max(0,configured-cnt),with_proxy,
                sum(p.engine == "camoufox" for p in profiles),
                sum(p.engine in ("chrome", "edge", "coccoc", "brave") for p in profiles),
                len({(p.os_type, (p.settings or {}).get("os_version","auto")) for p in profiles}),
                len({(p.settings or {}).get("device_class","desktop") for p in profiles})]
            for label,value in zip(self._metric_texts,values):
                label.value = str(value)
            info = inventory(profiles)
            engines = info["engines"]
            def engine_status(engine,label):
                item=engines[engine]
                installed="Sẵn sàng" if item["ready"] else "Chưa có runtime"
                return f"{label}: {installed} ({item['configured']} profile)"
            self._engine_inventory.value = "\n".join([
                engine_status(key,label) for key,label in (
                  ("camoufox","Camoufox"),("chrome","Chromium"),
                  ("edge","Edge"),("coccoc","Cốc Cốc"),("brave","Brave"))])
            os_summary=", ".join(f"{label}: {value}" for label,value in info["os_types"].items()) or "Chưa có profile"
            devices=", ".join(f"{label}: {value}" for label,value in info["device_classes"].items()) or "—"
            self._environment_text.value = f"OS: {os_summary} • Loại máy: {devices}"
            self._proxy_text.value = f"Có proxy: {with_proxy} • Kết nối trực tiếp: {configured-with_proxy} • Đã dừng: {configured-cnt}"


    @staticmethod
    def _choice(label: str, values: list[str]) -> ft.Dropdown:
        return ft.Dropdown(label=label,options=[ft.dropdown.Option(x,x) for x in values],
                           value=values[0] if values else None,expand=True)

    def _account_dialog(self) -> None:
        profile_names=list(self.pm.profiles)
        if not profile_names:
            self._log('Vui lòng tạo browser profile trước khi lưu tài khoản')
            return
        service=self._choice('Nền tảng',['Facebook','Instagram','Google','TikTok','Khác'])
        profile=self._choice('Browser Profile',profile_names)
        label=ft.TextField(label='Tên hiển thị',hint_text='Facebook Marketing 01')
        username=ft.TextField(label='Tên đăng nhập / email')
        url=ft.TextField(label='Địa chỉ đăng nhập',value='https://www.facebook.com/')
        password=ft.TextField(label='Mật khẩu (không bắt buộc, lưu mã hóa Windows)',password=True,can_reveal_password=True)
        note=ft.TextField(label='Ghi chú')
        error=ft.Text('',color=COLORS['error'],size=12)
        defaults={'Facebook':'https://www.facebook.com/','Instagram':'https://www.instagram.com/',
                  'Google':'https://accounts.google.com/','TikTok':'https://www.tiktok.com/'}
        def pick(_):
            url.value=defaults.get(service.value,'https://')
            self.page.update()
        service.on_select=pick
        def save(_):
            try:
                self.workspace.add_account(service.value,label.value or '',username.value or '',
                    url.value or '',profile.value,password.value or '',note.value or '')
            except Exception as ex:
                error.value=str(ex)
                self.page.update()
                return
            self.page.pop_dialog()
            self._refresh_workspace_ui()
        dlg=ft.AlertDialog(modal=True,title=ft.Text('Lưu tài khoản liên kết profile'),
            content=ft.Container(width=630,height=420,content=ft.Column(spacing=12,
              scroll=ft.ScrollMode.AUTO,controls=[ft.Row(controls=[service,profile]),label,username,
                                             url,password,note,error])),
            actions=[ft.TextButton('Hủy',on_click=lambda _:self.page.pop_dialog()),
                     ft.Button('Lưu tài khoản',icon=ft.Icons.SAVE,on_click=save)])
        self.page.show_dialog(dlg)

    def _bookmark_current_page(self, profile_name: str) -> None:
        """Save current browser tab without touching session tokens or cookies."""
        def worker():
            try:
                result=self.bl.control(profile_name,'tabs',{},timeout=12)
                tabs=result.get('tabs',[])
                active=next((x for x in tabs if x.get('active')),tabs[0] if tabs else None)
                if not active:
                    raise ValueError('Chưa có tab nào đang mở')
                self.workspace.add_bookmark(profile_name,active.get('title') or 'Bookmark',active.get('url') or '')
                self.workspace.activity('bookmark_saved',profile_name,active.get('title') or '')
                self._log('Đã lưu bookmark vào '+profile_name)
                self._refresh_workspace_ui()
            except Exception as exc:
                self._log('Không lưu được bookmark: '+str(exc))
        threading.Thread(target=worker,daemon=True).start()

    def _bookmark_dialog(self) -> None:
        names=list(self.pm.profiles)
        if not names:
            self._log('Vui lòng tạo browser profile trước khi thêm bookmark')
            return
        profile=self._choice('Browser Profile',names)
        label=ft.TextField(label='Tên bookmark',hint_text='Facebook Ads Manager')
        url=ft.TextField(label='URL',value='https://www.facebook.com/')
        category=ft.TextField(label='Danh mục',value='Social')
        error=ft.Text('',size=12,color=COLORS['error'])
        def save(_):
            try:
                self.workspace.add_bookmark(profile.value,label.value or '',url.value or '',category.value or '')
            except Exception as ex:
                error.value=str(ex)
                self.page.update()
                return
            self.page.pop_dialog()
            self._refresh_workspace_ui()
        dlg=ft.AlertDialog(modal=True,title=ft.Text('Thêm bookmark'),
             content=ft.Container(width=540,content=ft.Column(tight=True,spacing=12,
                   controls=[profile,label,url,category,error])),
             actions=[ft.TextButton('Hủy',on_click=lambda _:self.page.pop_dialog()),
                      ft.Button('Lưu bookmark',icon=ft.Icons.SAVE,on_click=save)])
        self.page.show_dialog(dlg)

    def _open_link(self, profile_name: str, url: str, activity_type: str) -> None:
        """Always navigate with the account's assigned persistent profile."""
        def worker():
            profile=self.pm.profiles.get(profile_name)
            if not profile:
                self._log('Profile không tồn tại: '+profile_name)
                return
            try:
                if not self.bl.is_running(profile_name):
                    if self.bl.start_thread(profile, self._log):
                        ok,err=self.bl.wait_for_launch(profile_name,90)
                        if not ok:
                            raise RuntimeError(err or 'Browser chưa sẵn sàng')
                self.bl.control(profile_name,'tab_new',{'url':url},timeout=40)
                self.workspace.activity(activity_type,profile_name,urlparse(url).hostname or '')
                self._log('Đã mở '+profile_name+' → '+url)
            except Exception as ex:
                self.workspace.activity('open_failed',profile_name,str(ex)[:200])
                self._log('Không mở được '+profile_name+': '+str(ex))
        threading.Thread(target=worker,daemon=True).start()

    def _fill_account(self, item_id: str) -> None:
        """Opt-in username/password fill; only on confirmed Facebook host, no auto-submit."""
        def worker():
            item=self.workspace.get_account(item_id)
            if not item:
                return
            try:
                if urlparse(item['url']).hostname not in ('facebook.com','www.facebook.com','m.facebook.com'):
                    raise ValueError('Điền tự động hiện chỉ hỗ trợ Facebook')
                host=self.bl.control(item['profile'],'evaluate',
                      {'script':'() => window.location.hostname'},timeout=10).get('result','')
                if host not in ('facebook.com','www.facebook.com','m.facebook.com'):
                    raise ValueError('Mở Facebook trong profile trước khi điền tài khoản')
                self.bl.control(item['profile'],'type',
                     {'selector':'input[name="email"]','text':item['username'],'submit':False},timeout=15)
                secret=self.workspace.decrypt_password(item_id)
                if secret:
                    self.bl.control(item['profile'],'type',
                     {'selector':'input[name="pass"]','text':secret,'submit':False},timeout=15)
                self.workspace.activity('login_form_filled',item['profile'],'manual submit')
                self._log('Đã điền tài khoản, vui lòng kiểm tra và đăng nhập thủ công')
            except Exception as ex:
                self._log('Không điền được tài khoản: '+str(ex))
        threading.Thread(target=worker,daemon=True).start()

    def _refresh_workspace_ui(self) -> None:
        """Render real bookmark/account/network rows, no hard-coded demo accounts."""
        if not hasattr(self,'_accounts_list'):
            return
        def badge(text):
            return ft.Container(bgcolor=COLORS['paper_sunk'],border_radius=7,
                padding=ft.Padding.symmetric(horizontal=8,vertical=5),
                content=ft.Text(str(text),size=11,color=COLORS['text_sub']))
        def item_row(icon,title,sub,actions):
            return ft.Container(padding=ft.Padding.symmetric(horizontal=4,vertical=11),
                border=ft.Border.only(bottom=ft.BorderSide(1,COLORS['card_border'])),
                content=ft.Row(spacing=12,controls=[
                    ft.Icon(icon,size=20,color=COLORS['accent']),
                    ft.Column(spacing=4,expand=True,controls=[
                        ft.Text(title,size=13.5,color=COLORS['text_main'],weight=ft.FontWeight.W_600),
                        ft.Text(sub,size=11.5,color=COLORS['text_sub'])]),*actions]))
        def delacc(k):
            self.workspace.delete_account(k);self._refresh_workspace_ui()
        def delbm(k):
            self.workspace.delete_bookmark(k);self._refresh_workspace_ui()
        accounts=self.workspace.list_accounts()
        self._accounts_list.controls=([item_row(ft.Icons.PERSON_OUTLINE,
             a['label'],f"{a['service']} • {a['username']} • {a['profile']} • Mật khẩu: {'đã mã hóa' if a['password_saved'] else 'không lưu'}",
             [ft.OutlinedButton('Mở',icon=ft.Icons.OPEN_IN_NEW,on_click=lambda _,a=a:self._open_link(a['profile'],a['url'],'account_opened')),
              ft.TextButton('Điền login',on_click=lambda _,k=a['id']:self._fill_account(k)),
              ft.IconButton(icon=ft.Icons.DELETE_OUTLINE,tooltip='Xóa liên kết',on_click=lambda _,k=a['id']:delacc(k))])
             for a in accounts] or [ft.Text('Chưa lưu tài khoản. Chọn Thêm tài khoản để liên kết với một browser profile.',size=13,color=COLORS['text_sub'])])
        bookmarks=self.workspace.list_bookmarks()
        self._bookmarks_list.controls=([item_row(ft.Icons.BOOKMARK_OUTLINE,b['label'],
             f"{b['url']} • Profile: {b['profile']}",
             [ft.OutlinedButton('Mở',icon=ft.Icons.OPEN_IN_NEW,on_click=lambda _,b=b:self._open_link(b['profile'],b['url'],'bookmark_opened')),
              ft.IconButton(icon=ft.Icons.DELETE_OUTLINE,tooltip='Xóa bookmark',on_click=lambda _,k=b['id']:delbm(k))])
             for b in bookmarks] or [ft.Text('Chưa có bookmark nào. Mỗi bookmark liên kết riêng với một profile.',size=13,color=COLORS['text_sub'])])
        audits=self.workspace.list_audits()
        self._audits_list.controls=([item_row(ft.Icons.LAN_OUTLINED,a['profile'],
             f"{a['status'].upper()}  •  IP: {a['exit_ip'] or 'Chưa xác minh'}  •  Proxy: {'Có' if a['proxy_enabled'] else 'Không'}  •  "
             f"Engine: {a['browser_engine'] or '—'}  •  OS: {a['platform'] or '—'}  •  "
             f"CPU: {a['cpu_cores'] or '—'}  •  Màn hình: {a['screen'] or '—'}  •  "
             f"Timezone: {a['timezone'] or '—'}  •  Profile Device ID: {a.get('device_id') or '—'}  •  WebGL: {a.get('webgl') or '—'}" + (f"  •  Lỗi: {a['error'][:70]}" if a['error'] else ''),[])
             for a in audits] or [ft.Text('Chưa có lần kiểm tra. Kết quả tự xuất hiện sau khi mở browser.',size=13,color=COLORS['text_sub'])])
        logs=self.workspace.recent_activity(80)
        self._activity_list.controls=([item_row(ft.Icons.HISTORY,
             f"{datetime.datetime.fromtimestamp(x['happened_at']).strftime('%d/%m/%Y %H:%M')}  •  {x['type']}",
             f"{x['profile']}  —  {x['detail']}",[]) for x in logs] or [ft.Text('Chưa có hoạt động.',size=13)])
        self._safe_update()

    def _log(self, message: str) -> None:
        logger.info(message)
        if self.state.add_log(message):
            self.state.schedule_refresh()

    def _flush_log(self) -> None:
        text = self.state.flush_log()
        if text is not None and self.refs:
            lines = text.split("\n")
            sidebar_lines = lines[-6:]
            self.refs.log_text.value = "\n".join(sidebar_lines)
            self.refs.log_column.height = max(72, len(sidebar_lines) * 18 + 20)
            self.refs.log_column.visible = bool(sidebar_lines) and not self.state.log_collapsed

    def _safe_update(self) -> None:
        if not self.page:
            return
        try:
            with self.state._ui_update_lock:
                self.page.update()
        except Exception as e:
            logger.error("Error updating UI: %s", e)

    async def _ui_reconcile_loop(self) -> None:
        while self.page:
            try:
                running_now = self.bl.running_profile_names()
                changed = running_now != self.state._last_running_snapshot
                if changed:
                    self.state._last_running_snapshot = running_now
                if changed or self.state.consume_refresh():
                    self._refresh_profiles()
            except Exception as e:
                logger.error("Error in UI reconcile loop: %s", e)
            await asyncio.sleep(0.12)

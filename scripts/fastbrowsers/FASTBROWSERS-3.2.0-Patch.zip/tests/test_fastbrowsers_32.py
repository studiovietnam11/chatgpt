"""Workstation regression: persistent bookmarks/accounts, IP audits, secure secrets."""
from __future__ import annotations
import os
import sqlite3
from pathlib import Path
import pytest

from src.services.profile.workspace import Workspace, safe_url

@pytest.fixture()
def store(tmp_path):
    return Workspace(tmp_path / "db" / "workspace.sqlite3")


def test_bookmark_crud_and_url_scheme_rejection(store):
    b = store.add_bookmark('FB-01', 'My Facebook', 'https://www.facebook.com/', 'Social')
    assert b['label'] == 'My Facebook'
    assert store.list_bookmarks('FB-01')[0]['id'] == b['id']
    assert store.list_bookmarks('another') == []
    with pytest.raises(ValueError):
        store.add_bookmark('FB-01', 'Invalid', 'javascript:alert(1)')
    with pytest.raises(ValueError):
        safe_url('http://localhost/private')
    with pytest.raises(ValueError):
        safe_url('https://user:pass@facebook.com/')
    assert store.delete_bookmark(b['id'])
    assert not store.delete_bookmark(b['id'])


def test_account_default_does_not_include_password_or_browser_cookie(store):
    a = store.add_account('Facebook', 'Ads 01', 'me@example.test', 'https://www.facebook.com/', 'FB-01')
    assert a['password_saved'] is False
    assert 'password' not in a and 'password_blob' not in a
    assert store.list_accounts()[0]['username'] == 'me@example.test'
    assert store.decrypt_password(a['id']) == ''
    assert store.delete_account(a['id'])


def test_password_never_written_as_plaintext_when_present(store, monkeypatch):
    from src.services.profile import workspace
    # Model Windows DPAPI on Linux CI; deployment uses actual Windows crypt32.
    if os.name != 'nt':
        monkeypatch.setattr(workspace, '_dpapi', lambda b, decrypt=False: b[::-1])
    pwd = 'Test--not-a-real-password--abc'
    a = store.add_account('Facebook', 'Personal', 'person', 'https://www.facebook.com/', 'FB-02',password=pwd)
    assert a['password_saved'] is True
    assert pwd.encode() not in store.path.read_bytes()
    assert store.decrypt_password(a['id']) == pwd
    assert 'password_blob' not in store.list_accounts()[0]


def test_audit_records_actual_or_unknown_ip_not_configured_guess(store):
    store.start_audit('FB-01','camoufox',True)
    pending = store.list_audits()[0]
    assert pending['status'] == 'checking' and pending['exit_ip'] is None
    store.finish_audit('FB-01', {'ip':'203.0.113.19','platform':'Win32','language':'vi-VN',
                  'timezone':'Asia/Ho_Chi_Minh','cpu':8,'screen':'1920x1080','userAgent':'UA'})
    row=store.list_audits()[0]
    assert row['status']=='checked' and row['exit_ip']=='203.0.113.19'
    assert row['proxy_enabled']==1 and row['cpu_cores']==8
    store.start_audit('FB-02','edge',False)
    store.finish_audit('FB-02', {'ipError':'No network','platform':'Win32'})
    row=store.list_audits()[0]
    assert row['status']=='error' and row['exit_ip']==''


def test_rename_preserves_associations(store):
    b=store.add_bookmark('Old','Facebook','https://www.facebook.com/')
    a=store.add_account('Facebook','Personal','me','https://www.facebook.com/','Old')
    store.start_audit('Old','camoufox',False)
    store.rename_profile('Old','New')
    assert store.list_bookmarks('New')[0]['id']==b['id']
    assert store.list_accounts('New')[0]['id']==a['id']
    assert store.list_audits()[0]['profile']=='New'
    assert any(item['profile']=='New' for item in store.recent_activity())


def test_persist_across_store_instances(store):
    b=store.add_bookmark('ABC','Saved','https://www.example.com/')
    new_instance=Workspace(store.path)
    assert new_instance.list_bookmarks()[0]['id']==b['id']


def test_gui_seven_tabs_in_real_flet_component_source():
    root=Path(__file__).parents[1]
    src=(root/'src/ui/components/content_area.py').read_text()
    assert all(x in src for x in ('overview','profiles','engines','network','bookmarks','accounts','activity'))
    assert 'holders' in src and 'select(key)' in src
    app=(root/'src/ui/app.py').read_text()
    assert 'def _account_dialog' in app and 'def _bookmark_dialog' in app


def test_network_probe_does_not_block_ready_event():
    root=Path(__file__).parents[1]
    src=(root/'src/services/browser/launcher.py').read_text()
    assert 'threading.Thread(target=self._audit_environment' in src
    assert 'self.control(name, "environment"' in src


def test_native_flet_dashboard_constructs_all_tabs():
    ft=pytest.importorskip('flet')
    from src.ui.components.content_area import build_content_area
    widget=build_content_area(
        ft.Text('Profiles'),ft.Column(),ft.IconButton(icon=ft.Icons.ARROW_LEFT),
        ft.IconButton(icon=ft.Icons.ARROW_RIGHT),ft.Text('1'),
        metrics=tuple(ft.Text('0') for _ in range(8)))
    assert widget.content.controls[1].content.controls.__len__()==7


def test_web_panel_javascript_is_extracted_and_has_workspace_tabs():
    root=Path(__file__).parents[1]
    html=(root/'src/web/index.html').read_text()
    assert 'id="workspace-nav"' in html
    assert 'fb-add-account' in html and 'fb-add-bookmark' in html
    assert 'fb-network-content' in html
    assert 'function switchWorkspace(key)' in html

# FASTBROWSERS 3.2.0 — Workspace, Accounts & Bookmarks

## Giao diện

Desktop Flet và web panel có 7 tab riêng: Tổng quan, Browser Profiles, Browser Engines, Network & IP, Bookmarks, Accounts & Login, Activity Logs. Không có thống kê giả. Font Inter, cam #FF6A00 và trắng.

## Kiểm tra môi trường

Sau khi tiến trình browser báo sẵn sàng, hệ thống kiểm tra ở luồng nền bằng chính browser profile: IP egress qua api.ipify.org, proxy có cấu hình hay không, user agent, platform, ngôn ngữ, timezone, CPU logic, độ phân giải và WebGL/GPU. Profile Device ID là SHA-256 rút gọn của cấu hình fingerprint lưu trên máy; không phải serial máy thật. Dịch vụ IP không phản hồi sẽ ghi "Chưa xác minh"/lỗi thay vì suy đoán. Tùy trình duyệt/cấu hình mạng, một số thuộc tính có thể không đọc được.

## Bookmark

Mỗi bookmark gắn với một profile. Có thể lưu URL thủ công, hoặc bấm ngôi sao ở hàng profile đang chạy để lưu tab hiện tại. Một nút sẽ mở URL trong profile gắn với bookmark.

## Tài khoản

Accounts riêng theo profile: nền tảng, tên gợi nhớ, tên đăng nhập, URL, ghi chú và mật khẩu tùy chọn. Mật khẩu lưu bằng Windows DPAPI theo Windows user, không lưu plaintext vào database hay gửi trả UI. Nếu mất Windows user/key, không phục hồi được mật khẩu. Không có đồng bộ cloud.

Bấm **Mở tài khoản** sẽ khởi chạy profile được gán nếu chưa chạy, sau đó mở URL trang đăng nhập/mạng xã hội trong profile đó. Cookie/session của browser được Playwright giữ trong user_data_dir tương ứng; chỉ khi website còn chấp nhận phiên đăng nhập thì tài khoản mới vào thẳng, không có bảo đảm vượt qua MFA/2FA. Không sao chép cookie giữa profile. "Điền login" là thao tác tùy chọn chỉ hỗ trợ trang Facebook và KHÔNG tự submit mật khẩu.

## An toàn và lưu trữ

Cơ sở dữ liệu SQLite riêng `fastbrowsers-workspace.sqlite3` nằm cạnh profiles.json trong `%LOCALAPPDATA%\FoxProfileStudio` để không làm mất dữ liệu cũ. Không ghi credential vào log. URL dùng http/https, mật khẩu chỉ được cho phép với HTTPS. Cơ chế API local-only/token sẵn có tiếp tục được dùng.

## Kiểm thử

Bài test Python cho CRUD, chia tab, mã hóa, URL nguy hiểm, ghi audit, lưu trạng thái, đổi tên profile, kiểm tra IP chưa xác minh và kiểm tra đóng gói. Builder Windows phải test trước khi phát hành. Bản phát hành thử nghiệm vẫn cần chạy nghiệm thu thực tế trên Windows 10/11 và các browser engine bên thứ ba.

"""FASTBROWSERS desktop entrypoint for the standalone Windows distribution.

Packaged builds run from an Inno Setup per-user installation; source builds
remain independent. Data, session and logs are stored outside the app dir.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_VERSION = "3.2.0"


def configure_workspace() -> Path:
    """Create *writable* user-owned paths. Never store secrets in Program Files."""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    root = base / "FoxProfileStudio"
    (root / "profiles").mkdir(parents=True, exist_ok=True)
    (root / "logs").mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("FOXPROFILE_PROFILES_FILE", str(root / "profiles.json"))
    os.environ.setdefault("FOXPROFILE_DATA_DIR", str(root / "profiles"))
    os.environ.setdefault("FOXPROFILE_LOG_DIR", str(root / "logs"))
    os.environ.setdefault("FOXPROFILE_LANG", "vi")
    # Do not change the parent process's CWD or replace pre-existing user data.
    return root


def configure_bundled_camoufox() -> Path | None:
    """Use the browser installed *in the setup*, without network at first start.

    Camoufox uses a package-level INSTALL_DIR constant. Patch it before other
    Camoufox modules are imported; the cache contains platform-matched assets
    downloaded on the Windows build worker. This package is pinned by CI.
    """
    if not getattr(sys, "frozen", False):
        return None
    runtime = Path(sys.executable).resolve().parent / "browser-runtime"
    if not runtime.is_dir():
        raise RuntimeError("Browser runtime missing. Reinstall FASTBROWSERS.")
    import camoufox.pkgman as pkgman
    pkgman.INSTALL_DIR = runtime
    return runtime


def self_test() -> int:
    """Offline check used by Windows build. No browser is launched or data altered."""
    configure_workspace()
    runtime = configure_bundled_camoufox()
    from src.api.app import _PANEL
    from src.ui.theme.page import ASSETS_DIR
    from camoufox.async_api import AsyncCamoufox  # noqa: F401
    from src.ui.app import App  # noqa: F401
    if not _PANEL.is_file() or not (Path(ASSETS_DIR) / "icon.png").is_file():
        raise RuntimeError("Packaged UI assets missing")
    if getattr(sys, "frozen", False):
        from camoufox.pkgman import launch_path
        if runtime is None or not Path(launch_path()).is_file():
            raise RuntimeError("Bundled Camoufox executable missing")
    print("FASTBROWSERS self-test OK", APP_VERSION, flush=True)
    return 0


def main() -> int:
    # PyInstaller --windowed sets stdout/stderr to None. Uvicorn uses isatty().
    if sys.stdout is None or sys.stderr is None:
        logs = configure_workspace() / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        if sys.stdout is None:
            sys.stdout = (logs / "desktop-console.log").open("a", encoding="utf-8", buffering=1)
        if sys.stderr is None:
            sys.stderr = (logs / "desktop-console.log").open("a", encoding="utf-8", buffering=1)
    if "--self-test" in sys.argv:
        return self_test()
    configure_workspace()
    configure_bundled_camoufox()
    from src.main import main as app_main
    app_main()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        import traceback
        # Error marker for desktop silent failures; logs are never placed in Program Files.
        try:
            root = configure_workspace()
            with (root / "logs" / "startup-error.log").open("a", encoding="utf-8") as f:
                f.write(f"\nStartup error: {type(exc).__name__}: {exc}\n")
                traceback.print_exc(file=f)
        except OSError:
            pass
        if os.name == "nt" and "--self-test" not in sys.argv:
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(None,
                    "FASTBROWSERS không thể khởi động.\n\nNhật ký: %LOCALAPPDATA%\\FoxProfileStudio\\logs\\startup-error.log\n\n" + str(exc)[:300],
                    "FASTBROWSERS - Startup error", 0x10)
            except Exception:
                pass
        traceback.print_exc()
        raise SystemExit(1)

"""Validated device preferences with explicit runtime capability boundaries.

We never advertise a metadata field as a spoofed signal. In 2.6, Camoufox
honors navigator.hardwareConcurrency and display width/height on creation;
Chrome honors hardware concurrency and selected platform version via persona.
Everything else is descriptive until a compatible engine implementation exists.
"""
from __future__ import annotations
from collections.abc import Mapping

DEFAULTS = {
    "device_class": "desktop",       # metadata, not device emulation
    "os_version": "auto",           # Chrome persona only
    "screen": "auto",               # Camoufox only
    "cpu_cores": 0,                 # both engines
    "ram_gb": 0,                    # metadata only
    "web_rtc": "engine",            # informational preference only
    "canvas": "engine",             # informational preference only
    "webgl": "engine",              # informational preference only
    "audio": "engine",              # informational preference only
    "media_input": 0,              # metadata only
    "media_output": 0,             # metadata only
    "group": "", "note": "",
}
DEVICE_CLASSES = ("desktop", "laptop", "workstation", "virtual_machine")
OS_VERSIONS = {
    "windows": ("auto", "windows10", "windows11"),
    "macos": ("auto", "macos14", "macos15", "macos26"),
    "linux": ("auto", "linux6"),
}
SCREENS = ("auto", "1280x720", "1366x768", "1440x900", "1600x900", "1920x1080", "2560x1440")
CPU_CORES = (0, 2, 4, 6, 8, 12, 16, 20)
RAM_GB = (0, 4, 8, 16, 32, 64)


def validate_settings(raw: Mapping | None, os_type: str = "windows") -> dict:
    if raw is None:
        return DEFAULTS.copy()
    if not isinstance(raw, Mapping):
        raise ValueError("Device settings must be an object")
    if set(raw) - set(DEFAULTS):
        raise ValueError("Unknown device settings: " + ", ".join(sorted(set(raw) - set(DEFAULTS))))
    s = {**DEFAULTS, **raw}
    for key, allowed in (("device_class", DEVICE_CLASSES), ("screen", SCREENS),
                         ("cpu_cores", CPU_CORES), ("ram_gb", RAM_GB),
                         ("web_rtc", ("engine",)), ("canvas", ("engine",)),
                         ("webgl", ("engine",)), ("audio", ("engine",))):
        if s[key] not in allowed or isinstance(s[key], bool):
            raise ValueError(f"Invalid {key}: {s[key]!r}")
    if s["os_version"] not in OS_VERSIONS.get(os_type, ("auto",)):
        raise ValueError(f"OS version {s['os_version']!r} is incompatible with {os_type}")
    for key in ("media_input", "media_output"):
        if type(s[key]) is not int or not 0 <= s[key] <= 8:
            raise ValueError(f"Invalid {key}")
    for key, limit in (("group", 50), ("note", 500)):
        if not isinstance(s[key], str) or len(s[key]) > limit:
            raise ValueError(f"Invalid {key}")
        s[key] = s[key].strip()
    return s


def supported_signals(engine: str) -> dict[str, str]:
    return {
        "device_class": "metadata", "os_version": "runtime" if engine == "chrome" else "metadata",
        "screen": "runtime" if engine == "camoufox" else "metadata",
        "cpu_cores": "runtime", "ram_gb": "metadata",
        "web_rtc": "engine_default", "canvas": "engine_default", "webgl": "engine_default",
        "audio": "engine_default", "media_input": "metadata", "media_output": "metadata",
        "group": "metadata", "note": "metadata",
    }

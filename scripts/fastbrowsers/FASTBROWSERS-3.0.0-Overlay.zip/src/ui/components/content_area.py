"""FASTBROWSERS dashboard: meaningful live metrics and profile workspace."""
import flet as ft
from ...core.strings import get_string
from ..theme.colors import COLORS, FONT_BOLD, FONT_SEMIBOLD


def _kpi(label: str, value: ft.Text, icon, highlight=False) -> ft.Container:
    value.size = 25
    value.weight = ft.FontWeight.W_700
    value.color = COLORS["accent"] if highlight else COLORS["text_main"]
    value.font_family = FONT_BOLD
    return ft.Container(
        expand=True, height=94, bgcolor=COLORS["card_bg"], border_radius=14,
        border=ft.Border.all(1, COLORS["card_border"]),
        padding=ft.Padding.symmetric(horizontal=16,vertical=13),
        content=ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[ft.Column(spacing=5,alignment=ft.MainAxisAlignment.CENTER,
                controls=[ft.Text(label,size=11.5,color=COLORS["text_sub"]),value]),
              ft.Container(width=38,height=38, border_radius=11,
                  bgcolor=COLORS["accent_soft"] if highlight else COLORS["paper_sunk"],
                  alignment=ft.Alignment(0,0),
                  content=ft.Icon(icon,size=19,color=COLORS["accent"] if highlight else COLORS["text_sub"]))]))


def _panel(title:str, eyebrow:str, details:ft.Text, icon, accent=False)->ft.Container:
    return ft.Container(expand=True,height=116,bgcolor=COLORS["card_bg"],
       border_radius=14,border=ft.Border.all(1,COLORS["card_border"]),
       padding=ft.Padding.symmetric(horizontal=17,vertical=13),
       content=ft.Column(spacing=6,controls=[
            ft.Row(spacing=8,controls=[ft.Icon(icon,color=COLORS["accent"] if accent else COLORS["text_sub"],size=17),
                ft.Text(title,size=13.5,color=COLORS["text_main"],weight=ft.FontWeight.W_600,font_family=FONT_SEMIBOLD)]),
            ft.Text(eyebrow,size=10.5,color=COLORS["accent"] if accent else COLORS["text_dim"]),
            details]))


def build_content_area(
    subtitle:ft.Text,profile_list:ft.Column,prev_btn:ft.IconButton,next_btn:ft.IconButton,
    page_label:ft.Text,bulk_bar:ft.Control|None=None,search_field:ft.Control|None=None,
    header_slot:ft.Container|None=None,metrics:tuple[ft.Text,...]|None=None,
    engine_inventory:ft.Text|None=None,environment_text:ft.Text|None=None,
    proxy_text:ft.Text|None=None,
)->ft.Container:
    sheet=ft.Container(height=365,bgcolor=COLORS["card_bg"],
        border=ft.Border.all(1,COLORS["card_border"]),border_radius=14,
        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        content=ft.Column(spacing=0,expand=True,controls=[
            *([] if bulk_bar is None else [bulk_bar]),
            *([] if header_slot is None else [header_slot]),profile_list]))
    controls=[
        ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,controls=[
             ft.Column(spacing=2,controls=[
               ft.Text('Dashboard',size=10.5,color=COLORS["accent"],weight=ft.FontWeight.W_700),
               ft.Text('Tổng quan hệ thống',size=29,weight=ft.FontWeight.W_700,
                       font_family=FONT_BOLD,color=COLORS["text_main"]),
               subtitle]),
             *([] if search_field is None else [search_field])]),
        ft.Container(height=17)]
    if metrics is not None and len(metrics)>=8:
        specs=[('Tổng profile',ft.Icons.LAYERS_OUTLINED,True),
           ('Đang hoạt động',ft.Icons.PLAY_CIRCLE_OUTLINED,False),
           ('Đã dừng',ft.Icons.PAUSE_CIRCLE_OUTLINE,False),
           ('Có proxy',ft.Icons.SHIELD_OUTLINED,False),
           ('Camoufox / Firefox',ft.Icons.PUBLIC,False),
           ('Chrome / Chromium',ft.Icons.WEB,True),
           ('Hệ điều hành / phiên bản',ft.Icons.DESKTOP_WINDOWS_OUTLINED,False),
           ('Loại máy tính',ft.Icons.DEVICES_OUTLINED,False)]
        for start in (0,4):
            controls.append(ft.Row(spacing=12,controls=[_kpi(specs[i][0],metrics[i],specs[i][1],specs[i][2]) for i in range(start,start+4)]))
            controls.append(ft.Container(height=11))
    if engine_inventory is not None and environment_text is not None and proxy_text is not None:
        for t in (engine_inventory,environment_text,proxy_text):
            t.size=11.5;t.color=COLORS["text_sub"];t.max_lines=3
        controls.extend([ft.Row(spacing=12,controls=[
            _panel('Browser engine','ENGINE INVENTORY · installed ≠ configured',engine_inventory,ft.Icons.MEMORY,True),
            _panel('Thiết bị & hệ điều hành','OS · DEVICE DISTRIBUTION',environment_text,ft.Icons.MONITOR),
            _panel('Kết nối & profile','PROXY · DIRECT · STATUS',proxy_text,ft.Icons.LAN)]),
          ft.Container(height=19)])
    controls.extend([
       ft.Row(spacing=10,vertical_alignment=ft.CrossAxisAlignment.CENTER,controls=[
           ft.Container(width=7,height=7,border_radius=8,bgcolor=COLORS["accent"]),
           ft.Text('QUẢN LÝ PROFILE',size=12,font_family=FONT_SEMIBOLD,color=COLORS["text_main"]),
           ft.Container(expand=True),
           ft.Icon(ft.Icons.LOCK_OUTLINE,size=15,color=COLORS["text_dim"]),
           ft.Text('Local workspace',size=11,color=COLORS["text_dim"])]),
       ft.Container(height=10),sheet,ft.Container(height=8),
       ft.Row(alignment=ft.MainAxisAlignment.END,controls=[prev_btn,page_label,next_btn]),
       ft.Container(height=16)])
    return ft.Container(expand=True,bgcolor=COLORS["bg"],
       padding=ft.Padding.only(left=26,right=26,top=22,bottom=10),
       content=ft.Column(expand=True,scroll=ft.ScrollMode.AUTO,spacing=0,controls=controls))

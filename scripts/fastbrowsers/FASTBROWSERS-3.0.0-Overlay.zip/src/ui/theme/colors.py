"""FASTBROWSERS • professional bright design system (orange + white)."""
COLORS = {
    "bg":"#F7F8FA","card_bg":"#FFFFFF","paper_sunk":"#F5F6F8",
    "card_border":"#EAECF0","rule_strong":"#D0D5DD","border":"#EAECF0",
    "text_main":"#17202D","text_sub":"#525F70","text_dim":"#8994A5",
    "input_bg":"#FFFFFF","sidebar":"#FFFFFF","cover_deep":"#F6F7F9",
    "cover_ink":"#17202D","cover_muted":"#657385","log_bg":"#F8FAFC",
    "accent":"#FF6A00","accent_hover":"#E85D00","accent_soft":"#FFF1E7",
    "ink_button":"#1D2939","live":"#16A34A","card_hover":"#FFF7F1",
    "card_selected_bg":"#FFF3EA","card_selected_border":"#FF6A00",
    "success":"#16865D","error":"#DC3545","delete_hover":"#B91C1C",
    "warning":"#B7791F","warn_tint":"#FFF8E8","warn_text":"#855D1B",
    "cover_line":"#EAECF0","scrollbar_bg":"#F5F7FB","scrollbar_grab":"#D0D5DD"
}
FONT = "Inter"
FONT_MEDIUM = "Inter Medium"
FONT_SEMIBOLD = "Inter SemiBold"
FONT_BOLD = "Inter Bold"
FONT_DATA = "Inter"

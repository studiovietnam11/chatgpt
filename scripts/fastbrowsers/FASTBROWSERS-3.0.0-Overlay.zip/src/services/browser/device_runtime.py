"""Apply only supported device settings to actual browser-engine inputs."""
import json
import os
from pathlib import Path
from ...core.config import PROFILES_FILE
from ...models.device_settings import validate_settings


def read_settings(profile_name: str, os_type: str) -> dict:
    try:
        with Path(PROFILES_FILE).open(encoding="utf-8") as h:
            raw = json.load(h).get(profile_name, {}).get("settings")
        return validate_settings(raw, os_type)
    except (OSError, ValueError, TypeError):
        return validate_settings(None, os_type)


def apply_camoufox(fingerprint: dict, settings: dict) -> dict:
    """Override coherent browserforge values, retaining all other seeded values."""
    fp = json.loads(json.dumps(fingerprint))
    cpu = settings.get("cpu_cores", 0)
    if cpu:
        fp.setdefault("navigator", {})["hardwareConcurrency"] = cpu
    screen = settings.get("screen", "auto")
    if screen != "auto":
        w, h = map(int, screen.split("x"))
        fp.setdefault("screen", {})["width"] = w
        fp["screen"]["height"] = h
        # Keep available viewport below total screen; no conflicting large values.
        fp["screen"]["availWidth"] = min(fp["screen"].get("availWidth", w), w)
        fp["screen"]["availHeight"] = min(fp["screen"].get("availHeight", h), h)
    return fp


def chrome_persona_overrides(settings: dict) -> dict:
    overrides = {}
    cpu = settings.get("cpu_cores", 0)
    if cpu:
        overrides["hardware_concurrency"] = cpu
    mapping = {
        "windows10": "10.0.0", "windows11": "19.0.0",
        "macos14": "14.7.6", "macos15": "15.6.1", "macos26": "26.0.1",
        "linux6": "6.8.0",
    }
    if settings.get("os_version") in mapping:
        overrides["platform_version"] = mapping[settings["os_version"]]
    return overrides

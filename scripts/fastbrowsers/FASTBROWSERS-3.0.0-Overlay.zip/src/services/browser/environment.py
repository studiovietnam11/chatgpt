"""Inventory of actual engine installations and configured profile environments."""
from __future__ import annotations
from collections import Counter
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Iterable
from ...models.profile import Profile


def inventory(profiles: Iterable[Profile]) -> dict:
    all_profiles = list(profiles)
    counts = Counter(p.engine for p in all_profiles)
    os_types = Counter(p.os_type for p in all_profiles)
    os_versions = Counter((p.os_type, (p.settings or {}).get('os_version','auto')) for p in all_profiles)
    device_classes = Counter((p.settings or {}).get('device_class','desktop') for p in all_profiles)
    try:
        cam_version = version('camoufox')
    except PackageNotFoundError:
        cam_version = None
    try:
        from camoufox.pkgman import INSTALL_DIR
        cam_ready = Path(INSTALL_DIR).exists()
    except Exception:
        cam_ready = False
    try:
        from chrome_engine import fetch
        chrome_path = fetch.installed_executable()
    except Exception:
        chrome_path = None
    return {
        'total':len(all_profiles),
        'engines': {
            'camoufox': {'configured':counts['camoufox'], 'version':cam_version, 'ready':cam_ready},
            'chrome': {'configured':counts['chrome'], 'version':'experimental', 'ready': bool(chrome_path)},
        },
        'os_types':dict(os_types),
        'os_versions':{f'{os}/{v}':n for (os,v),n in os_versions.items()},
        'device_classes':dict(device_classes),
        'proxy_profiles':sum(bool(p.proxy) for p in all_profiles),
    }

# FASTBROWSERS Studio 3.0.0

## Theme
- FASTBROWSERS branding in desktop Flet, web panel, Windows icon and installer.
- Primary #FF6A00; white surfaces; Inter typography (bundled by Windows CI from official source, system fallback for source development).

## Dashboard
- Aggregates configured/running/stopped profiles, proxy/direct, Camoufox/Chrome, OS and device classes.
- Lists actual engine installation readiness separate from number of profiles.
- Profile devices include configurable OS version, screen, cores, RAM metadata and engine-default fingerprint signals. Unsupported spoof switches are not misrepresented.

## Important
- Preserve FOXPROFILE_* environment variables and existing LOCALAPPDATA/FoxProfileStudio data paths for backward compatibility.
- Windows build must be verified by launching the actual GUI (not import-only smoke tests).
- Changing engine and arbitrary device signals can increase inconsistency or browser detection; only supported settings affect runtime.

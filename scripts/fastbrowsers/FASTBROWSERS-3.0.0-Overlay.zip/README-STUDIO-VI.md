# FASTBROWSERS 2.4.0 — bản thiết kế lại và bộ build Windows

## Những gì đã thay đổi

- Giao diện desktop Flet: sidebar tối xanh navy, nền sáng, nút primary xanh, thẻ tổng quan 3 chỉ số, hàng profile rõ ràng và badge trạng thái; tối ưu khoảng cách, viền và chữ.
- Giao diện web panel: thiết kế thống nhất, bổ sung thống kê theo dữ liệu thật, layout ứng dụng trên màn hình nhỏ.
- Toàn bộ thao tác cũ (tạo/sửa/xóa profile, cookie, proxy, import/export, bulk launch/stop, API/MCP) được giữ về mặt mã nguồn/handler.
- Thay font nhúng bằng font hệ thống Windows. Không phân phối font bên thứ ba.
- `studio_launcher.py` tách dữ liệu profile và log khỏi thư mục chương trình, giữ dữ liệu khi nâng cấp/gỡ cài.
- `windows/build-windows.ps1` + `.github/workflows/windows-offline-installer.yml` để build một **Setup.exe Windows có đầy đủ runtime offline**.

## Tạo EXE chỉ một lần

Cách đơn giản nhất: tải ZIP này lên **repository GitHub của bạn**, mở **Actions → Build FASTBROWSERS offline Windows installer → Run workflow**. Khi workflow xanh, tải artifact `FASTBROWSERSStudio-Setup-Win64`. Giải nén artifact, dùng file `FASTBROWSERSStudio-Setup-2.4.0-Win64.exe` để cài trên nhiều máy.

Lưu ý: "một file EXE" là **kết quả của workflow Windows**, không phải một file giả `.exe` nhỏ vài trăm KB đi tải Python trên máy người dùng.

## Trạng thái kiểm thử

Đã kiểm tra: cú pháp Python, mã nguồn Flet/web, 46 bài kiểm thử Python không cần GUI, giao diện demo HTML độc lập. **Chưa chạy build Windows native, chưa có EXE phát hành và chưa test mở trình duyệt Camoufox trên Windows.** Không thể cam kết bộ cài hoạt động trên mọi PC khi chưa có build Windows xanh và QA trên máy đích.

## Vị trí dữ liệu sau khi cài

- Chương trình: `%LOCALAPPDATA%\Programs\FASTBROWSERSStudio`
- Profile, cookie, log: `%LOCALAPPDATA%\FASTBROWSERSStudio`

Không tự động di chuyển dữ liệu của FASTBROWSERS cũ. Hãy sao lưu và import chủ động.

## An toàn khi phân phối

Bản build không cài Python hệ thống, không tải package qua Internet trên máy đích. **Chưa ký số code signing**; Windows SmartScreen có thể hiện cảnh báo. Phiên bản trình duyệt/phụ thuộc có thể thay đổi theo lúc build nếu không khóa phiên bản, nên cần nghiệm thu artifact và lưu SHA-256 trước khi phát cho nhiều máy.

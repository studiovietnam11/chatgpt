# FASTBROWSERS - Cài trên Windows 10/11

**Máy người dùng:** Khi đã có `FASTBROWSERS-Setup-3.0.0-Win64.exe` build và kiểm thử thành công, chỉ việc bấm đúp → Install → Finish. Không cần cài Python.

**Máy build (developer):** Chạy GitHub Actions `FASTBROWSERS Windows installer` trên repo chứa toàn bộ mã nguồn hoặc dùng `windows/build-FASTBROWSERS.ps1` trên Windows có Python 3.12 và Inno Setup 6. Build sẽ tải sẵn Camoufox và thư viện Inter.

**Tương thích:** tên chương trình là FASTBROWSERS, nhưng dữ liệu các bản FoxProfile Studio được giữ tại `%LOCALAPPDATA%\FoxProfileStudio` và các biến nội bộ FOXPROFILE_* để tránh mất profile. Không xóa thư mục đó khi nâng cấp.

**Cảnh báo:** mã nguồn ZIP **không** phải EXE. Chỉ phát hành EXE sau khi workflow Windows thành công, ứng dụng thực sự chạy và profile Camoufox mở được trên máy Windows.

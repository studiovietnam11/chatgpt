"""Build-time tests for the redistributable release layout and local data isolation."""
from __future__ import annotations

import os
from pathlib import Path


def test_workspace_is_under_user_data(tmp_path, monkeypatch):
    monkeypatch.setenv('XDG_DATA_HOME', str(tmp_path))
    for key in ('FOXPROFILE_PROFILES_FILE', 'FOXPROFILE_DATA_DIR', 'FOXPROFILE_LOG_DIR'):
        monkeypatch.delenv(key, raising=False)
    from studio_launcher import configure_workspace
    root = configure_workspace()
    assert root == tmp_path / 'FoxProfileStudio' if os.name != 'nt' else root.name == 'FoxProfileStudio'
    assert (root / 'profiles').is_dir()
    assert (root / 'logs').is_dir()
    assert Path(os.environ['FOXPROFILE_PROFILES_FILE']).parent == root


def test_native_setup_does_not_download_dependencies():
    src = Path(__file__).resolve().parents[2] / 'windows' / 'FoxProfileStudio.iss'
    text = src.read_text(encoding='utf-8').lower()
    assert 'powershell.exe' not in text
    assert 'pip install' not in text
    assert 'camoufox fetch' not in text
    assert 'dist\\foxprofilestudio\\*' in text


def test_web_panel_has_css_design_system():
    html = (Path(__file__).resolve().parents[2] / 'src' / 'web' / 'index.html').read_text()
    for color in ['#F5F7FB', '#111E31', '#2563EB', '#09856D']:
        assert color in html
    assert 'BeVietnamPro-Regular.ttf' not in html

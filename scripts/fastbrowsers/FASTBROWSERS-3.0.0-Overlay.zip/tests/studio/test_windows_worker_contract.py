"""Worker packaging contract: avoids relaunching the frozen Flet GUI as python."""
from pathlib import Path
from types import SimpleNamespace
import sys

from src.services.browser import process


def sample(engine="camoufox"):
    return SimpleNamespace(
        name="tester", proxy=None, os_type="windows", timezone="", locale="", engine=engine
    )


def test_source_mode_still_uses_python(monkeypatch):
    monkeypatch.delattr(sys, "frozen", raising=False)
    cmd = process.runner_command(sample())
    assert cmd[0] == sys.executable
    assert cmd[-5:] == ["tester", "None", "windows", "", ""]


def test_frozen_uses_worker_and_preserves_protocol(monkeypatch, tmp_path):
    (tmp_path / "worker").mkdir()
    worker = tmp_path / "worker" / "FoxProfileWorker.exe"
    worker.write_bytes(b"MZ")
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "executable", str(tmp_path / "FoxProfileStudio.exe"))
    cmd = process.runner_command(sample())
    assert Path(cmd[0]) == worker
    assert cmd[1] == "--camoufox"
    assert cmd[-5:] == ["tester", "None", "windows", "", ""]
    chrome = process.runner_command(sample("chrome"))
    assert chrome[1] == "--chrome"


def test_frozen_missing_worker_errors_early(monkeypatch, tmp_path):
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "executable", str(tmp_path / "FoxProfileStudio.exe"))
    try:
        process.runner_command(sample())
        assert False, "Should fail instead of silently launching GUI as Python"
    except FileNotFoundError as exc:
        assert "FoxProfileWorker.exe" in str(exc)

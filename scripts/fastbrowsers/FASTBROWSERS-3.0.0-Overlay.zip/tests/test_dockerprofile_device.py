import json
import os
import pytest
from src.models.device_settings import DEFAULTS, validate_settings, supported_signals
from src.services.browser.device_runtime import apply_camoufox, chrome_persona_overrides, read_settings
from src.services.profile.manager import ProfileManager


def test_validated_settings_defaults_and_unsupported_are_explicit():
    s = validate_settings(None)
    assert s == DEFAULTS
    assert supported_signals('camoufox')['screen'] == 'runtime'
    assert supported_signals('chrome')['screen'] == 'metadata'
    assert supported_signals('camoufox')['ram_gb'] == 'metadata'
    with pytest.raises(ValueError):
        validate_settings({'cpu_cores':999})
    with pytest.raises(ValueError):
        validate_settings({'os_version':'windows11'}, 'macos')


def test_stable_camoufox_config_does_not_modify_generator_object():
    seed = {'navigator': {'hardwareConcurrency': 8,'platform':'Win32'}, 'screen':{'width':1920,'height':1080,'availWidth':1900,'availHeight':1030}}
    result = apply_camoufox(seed, validate_settings({'cpu_cores': 12, 'screen':'1366x768'}))
    assert result['navigator']['hardwareConcurrency'] == 12
    assert result['screen']['width'] == 1366
    assert result['screen']['height'] == 768
    assert result['screen']['availWidth'] <= 1366
    assert seed['navigator']['hardwareConcurrency'] == 8


def test_chrome_platform_version_and_cpu():
    result = chrome_persona_overrides(validate_settings({'os_version':'windows11', 'cpu_cores':16}))
    assert result == {'hardware_concurrency':16, 'platform_version':'19.0.0'}


def test_profile_data_migration_and_roundtrip(tmp_path, monkeypatch):
    import src.services.profile.manager as manager_module
    monkeypatch.setattr(manager_module, 'PROFILES_FILE', str(tmp_path/'profiles.json'))
    monkeypatch.setattr(manager_module, 'DATA_DIR', str(tmp_path/'browser-data'))
    pm=ProfileManager()
    assert pm.add_profile('Client 01','', 'windows', engine='camoufox', settings={'device_class':'laptop','cpu_cores':8, 'group':'Sales'})
    data=json.loads((tmp_path/'profiles.json').read_text())
    assert data['Client 01']['settings']['group'] == 'Sales'
    pm2=ProfileManager()
    assert pm2.profiles['Client 01'].settings['cpu_cores']==8
    assert pm2.update_profile('Client 01','Client 01','', 'windows', settings={'device_class':'desktop','os_version':'windows10'})
    data=json.loads((tmp_path/'profiles.json').read_text())
    assert data['Client 01']['settings']['os_version'] == 'windows10'
    monkeypatch.setattr('src.services.browser.device_runtime.PROFILES_FILE', str(tmp_path/'profiles.json'))
    assert read_settings('Client 01','windows')['os_version'] == 'windows10'

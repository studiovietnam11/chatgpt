# Docker Profile Studio 2.6.0 — mã nguồn nâng cấp

## Đã triển khai
- Đổi nhãn thương hiệu thành Docker Profile trên giao diện Flet và dashboard web. Mã cấu hình FOXPROFILE_ giữ nguyên để tương thích dữ liệu cũ. Docker Profile là tên ứng dụng, **không phải Docker container**.
- Bổ sung loại máy (desktop/laptop/workstation/VM), OS và phiên bản OS, màn hình, CPU, RAM, nhóm, ghi chú; lưu, sửa, nhập/xuất qua profiles.json.
- Áp dụng CPU/screen trên Camoufox và CPU/OS version qua persona Chrome. Loại máy/RAM là trường quản lý, không giả mạo phần cứng; WebRTC/Canvas/WebGL/Audio theo engine mặc định. Không đảm bảo vượt kiểm tra chống phát hiện.
- Dashboard đếm Camoufox, Chrome, phiên bản OS, loại máy; thêm API /api/v1/environment.
- Ngăn hiện cửa sổ console đen cho process trình duyệt trên Windows.
- Cache IP proxy 15 phút và giới hạn kiểm tra IP 8 giây để tránh chờ lâu mỗi lần khởi động. Proxy không kết nối được sẽ thông báo lỗi, không tự chuyển sang direct.
- Icon và hệ màu violet/indigo mới, bảng profile hiển thị nhóm và loại thiết bị.

## Chưa nghiệm thu
- Chưa build bản Setup.exe trên Windows cho 2.6.0, không coi ZIP mã nguồn là bộ cài.
- Không bảo đảm mọi loại fingerprint được thực thi (xem các ghi chú runtime/metadata).
- Chưa kiểm thử UI desktop Flet trên Windows; kiểm tra syntax Python và JS đã đạt.
- Chrome experimental vẫn có thể tải engine lần đầu; để có bộ cài hoàn toàn offline phải kèm Chrome engine trong Windows build.

## Nguồn
Kế thừa mã nguồn FoxProfile 2.5.0 và MIT License; chỉnh sửa theo yêu cầu Docker Profile.

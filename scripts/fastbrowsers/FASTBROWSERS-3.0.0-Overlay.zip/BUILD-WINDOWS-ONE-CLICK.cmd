@echo off
setlocal
cd /d "%~dp0"
title FoxProfile Studio 2.5.0 - Windows Build
if not exist "windows\build-windows.ps1" (
    echo ERROR: Extract the entire ZIP before running this file.
    pause
    exit /b 1
)
where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python 3.12 is required on the BUILD PC.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\build-windows.ps1"
set "rc=%ERRORLEVEL%"
echo.
if not "%rc%"=="0" (
    echo BUILD FAILED, code %rc%
    echo Open build-logs\build-latest.log for details.
) else (
    echo BUILD SUCCESS! Open folder release\ for the one-file Setup.exe.
)
echo.
pause
exit /b %rc%
